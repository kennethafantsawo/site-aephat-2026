import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Language, 
  UserRole, 
  AdminRole, 
  Post, 
  HealthArticle, 
  Survey, 
  User, 
  CommentItem, 
  BoardMember 
} from '../types';
import { 
  initialPosts, 
  initialHealthArticles, 
  initialSurveys, 
  initialPendingMembers, 
  initialComments,
  initialBoardMembers 
} from '../data/initialData';
import { translations } from '../data/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.fr;
  
  // Admin Mode & Roles
  isAdminMode: boolean;
  setIsAdminMode: (mode: boolean) => void;
  adminRole: AdminRole;
  setAdminRole: (role: AdminRole) => void;

  // Member Authentication
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  login: (email: string, password?: string) => boolean;
  loginAsDemoUser: (type: 'student' | 'doctor' | 'citizen' | 'admin') => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalTab: 'login' | 'register';
  setAuthModalTab: (tab: 'login' | 'register') => void;

  // Posts
  posts: Post[];
  addPost: (newPost: Omit<Post, 'id' | 'likes'>) => void;
  editPost: (id: string, updated: Partial<Post>) => void;
  deletePost: (id: string) => void;
  likePost: (id: string) => void;
  publishPostNow: (id: string) => void;

  // Board Executive (Le Bureau)
  boardMembers: BoardMember[];
  addBoardMember: (member: Omit<BoardMember, 'id'>) => void;
  editBoardMember: (id: string, updated: Partial<BoardMember>) => void;
  deleteBoardMember: (id: string) => void;

  // Health Articles (OMS & Vidal)
  healthArticles: HealthArticle[];
  addHealthArticle: (article: Omit<HealthArticle, 'id'>) => void;
  deleteHealthArticle: (id: string) => void;
  lastHealthSyncTime: string;
  isSyncingHealth: boolean;
  syncHealthWithOmsAndVidal: () => Promise<void>;

  // Surveys & Google Forms
  surveys: Survey[];
  addSurvey: (survey: Omit<Survey, 'id' | 'responsesCount'>) => void;
  editSurvey: (id: string, updated: Partial<Survey>) => void;
  deleteSurvey: (id: string) => void;
  toggleSurveyActive: (id: string) => void;

  // Comments (Immediately visible & moderated)
  comments: CommentItem[];
  addComment: (comment: Omit<CommentItem, 'id' | 'createdAt' | 'status'> & { status?: CommentItem['status'] }) => void;
  updateCommentStatus: (id: string, status: CommentItem['status'], adminReply?: string) => void;
  deleteComment: (id: string) => void;
  activeCommentsPostId: string | null;
  setActiveCommentsPostId: (id: string | null) => void;

  // Member Management
  members: User[];
  registerMember: (data: { name: string; email: string; role: UserRole; facultyId?: string; academicYear?: string; phone?: string }) => void;
  addMember: (member: Omit<User, 'id' | 'joinedAt'>) => void;
  editMember: (id: string, updated: Partial<User>) => void;
  approveMember: (userId: string) => void;
  rejectMember: (userId: string) => void;
  deleteMember: (userId: string) => void;

  // Modals & Navigation
  activeCommentTarget: { type: 'post' | 'survey' | 'suggestion'; id: string; title: string } | null;
  setActiveCommentTarget: (target: { type: 'post' | 'survey' | 'suggestion'; id: string; title: string } | null) => void;
  activeStatsSurvey: Survey | null;
  setActiveStatsSurvey: (survey: Survey | null) => void;
  activeReadArticle: HealthArticle | null;
  setActiveReadArticle: (art: HealthArticle | null) => void;
  activeReadPost: Post | null;
  setActiveReadPost: (post: Post | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('fr');
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [adminRole, setAdminRole] = useState<AdminRole>('president');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [activeCommentsPostId, setActiveCommentsPostId] = useState<string | null>(null);

  // Modals
  const [activeCommentTarget, setActiveCommentTarget] = useState<{
    type: 'post' | 'survey' | 'suggestion';
    id: string;
    title: string;
  } | null>(null);
  const [activeStatsSurvey, setActiveStatsSurvey] = useState<Survey | null>(null);
  const [activeReadArticle, setActiveReadArticle] = useState<HealthArticle | null>(null);
  const [activeReadPost, setActiveReadPost] = useState<Post | null>(null);

  // Authenticated user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('aephat_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Posts State
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('aephat_posts_v2');
    return saved ? JSON.parse(saved) : initialPosts;
  });

  // Board Members State
  const [boardMembers, setBoardMembers] = useState<BoardMember[]>(() => {
    const saved = localStorage.getItem('aephat_board_members');
    return saved ? JSON.parse(saved) : initialBoardMembers;
  });

  // Health Articles State
  const [healthArticles, setHealthArticles] = useState<HealthArticle[]>(() => {
    const saved = localStorage.getItem('aephat_health_articles_v2');
    return saved ? JSON.parse(saved) : initialHealthArticles;
  });

  // Surveys State
  const [surveys, setSurveys] = useState<Survey[]>(() => {
    const saved = localStorage.getItem('aephat_surveys_v2');
    return saved ? JSON.parse(saved) : initialSurveys;
  });

  // Comments State (Public & Moderated)
  const [comments, setComments] = useState<CommentItem[]>(() => {
    const saved = localStorage.getItem('aephat_comments_v2');
    return saved ? JSON.parse(saved) : initialComments;
  });

  // Members State
  const [members, setMembers] = useState<User[]>(() => {
    const saved = localStorage.getItem('aephat_members_v2');
    return saved ? JSON.parse(saved) : initialPendingMembers;
  });

  // Last health sync
  const [lastHealthSyncTime, setLastHealthSyncTime] = useState<string>(() => {
    return localStorage.getItem('aephat_last_health_sync_label') || 'Il y a 15 minutes (Actualisé OMS & VIDAL)';
  });
  const [isSyncingHealth, setIsSyncingHealth] = useState(false);

  // Persist State to localStorage
  useEffect(() => {
    localStorage.setItem('aephat_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('aephat_posts_v2', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('aephat_board_members', JSON.stringify(boardMembers));
  }, [boardMembers]);

  useEffect(() => {
    localStorage.setItem('aephat_health_articles_v2', JSON.stringify(healthArticles));
  }, [healthArticles]);

  useEffect(() => {
    localStorage.setItem('aephat_surveys_v2', JSON.stringify(surveys));
  }, [surveys]);

  useEffect(() => {
    localStorage.setItem('aephat_comments_v2', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('aephat_members_v2', JSON.stringify(members));
  }, [members]);

  // Hourly Auto-Sync for OMS & VIDAL
  useEffect(() => {
    const checkHourlySync = () => {
      const lastTs = localStorage.getItem('aephat_last_health_sync_ts');
      const now = Date.now();
      const oneHour = 3600000;

      if (!lastTs || now - parseInt(lastTs, 10) > oneHour) {
        syncHealthWithOmsAndVidal();
      }
    };

    checkHourlySync();
    const interval = setInterval(checkHourlySync, 60000); // check every minute
    return () => clearInterval(interval);
  }, []);

  // Post Actions
  const addPost = (newPostData: Omit<Post, 'id' | 'likes'>) => {
    const newPost: Post = {
      ...newPostData,
      id: `post-${Date.now()}`,
      likes: 0,
      title: {
        fr: newPostData.title.fr,
        en: newPostData.title.en || newPostData.title.fr,
      },
      excerpt: {
        fr: newPostData.excerpt.fr,
        en: newPostData.excerpt.en || newPostData.excerpt.fr,
      },
      content: {
        fr: newPostData.content.fr,
        en: newPostData.content.en || newPostData.content.fr,
      },
      status: newPostData.status || 'published',
    };
    setPosts(prev => [newPost, ...prev]);
  };

  const editPost = (id: string, updated: Partial<Post>) => {
    setPosts(prev => prev.map(p => {
      if (p.id !== id) return p;
      return {
        ...p,
        ...updated,
        title: {
          fr: updated.title?.fr ?? p.title.fr,
          en: updated.title?.en || updated.title?.fr || p.title.en,
        },
        excerpt: {
          fr: updated.excerpt?.fr ?? p.excerpt.fr,
          en: updated.excerpt?.en || updated.excerpt?.fr || p.excerpt.en,
        },
        content: {
          fr: updated.content?.fr ?? p.content.fr,
          en: updated.content?.en || updated.content?.fr || p.content.en,
        },
      };
    }));
  };

  const deletePost = (id: string) => {
    setPosts(prev => prev.filter(p => p.id !== id));
    // Clean associated comments
    setComments(prev => prev.filter(c => c.targetId !== id));
  };

  const likePost = (id: string) => {
    setPosts(prev => prev.map(p => (p.id === id ? { ...p, likes: p.likes + 1 } : p)));
  };

  const publishPostNow = (id: string) => {
    setPosts(prev => prev.map(p => (p.id === id ? { ...p, status: 'published' } : p)));
  };

  // Board Executive Actions
  const addBoardMember = (memberData: Omit<BoardMember, 'id'>) => {
    const newMember: BoardMember = {
      ...memberData,
      id: `board-${Date.now()}`,
      order: boardMembers.length + 1,
    };
    setBoardMembers(prev => [...prev, newMember]);
  };

  const editBoardMember = (id: string, updated: Partial<BoardMember>) => {
    setBoardMembers(prev => prev.map(m => (m.id === id ? { ...m, ...updated } : m)));
  };

  const deleteBoardMember = (id: string) => {
    setBoardMembers(prev => prev.filter(m => m.id !== id));
  };

  // Health Articles Actions (OMS & VIDAL)
  const addHealthArticle = (articleData: Omit<HealthArticle, 'id'>) => {
    const newArticle: HealthArticle = {
      ...articleData,
      id: `health-${Date.now()}`,
      importedAt: 'À l’instant',
    };
    setHealthArticles(prev => [newArticle, ...prev]);
  };

  const deleteHealthArticle = (id: string) => {
    setHealthArticles(prev => prev.filter(a => a.id !== id));
  };

  const syncHealthWithOmsAndVidal = async () => {
    setIsSyncingHealth(true);
    await new Promise(res => setTimeout(res, 900));

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const newLabel = `Actualisé à ${timeStr} (OMS & VIDAL)`;

    setLastHealthSyncTime(newLabel);
    localStorage.setItem('aephat_last_health_sync_label', newLabel);
    localStorage.setItem('aephat_last_health_sync_ts', Date.now().toString());

    // Check if new latest bulletins should be updated
    setHealthArticles(prev => {
      // Ensure we have both OMS and VIDAL articles present
      const hasVidal = prev.some(a => a.sourceType === 'VIDAL');
      const hasWho = prev.some(a => a.sourceType === 'OMS');
      if (hasVidal && hasWho) {
        return prev.map(a => ({
          ...a,
          importedAt: `Synchronisé à ${timeStr}`,
        }));
      }
      return initialHealthArticles;
    });

    setIsSyncingHealth(false);
  };

  // Survey Actions
  const addSurvey = (surveyData: Omit<Survey, 'id' | 'responsesCount'>) => {
    const newSurvey: Survey = {
      ...surveyData,
      id: `survey-${Date.now()}`,
      responsesCount: 0,
      title: {
        fr: surveyData.title.fr,
        en: surveyData.title.en || surveyData.title.fr,
      },
      description: {
        fr: surveyData.description.fr,
        en: surveyData.description.en || surveyData.description.fr,
      },
      resultsAccessEmail: surveyData.resultsAccessEmail || 'commission.sondages@aephat.tg',
    };
    setSurveys(prev => [newSurvey, ...prev]);
  };

  const editSurvey = (id: string, updated: Partial<Survey>) => {
    setSurveys(prev => prev.map(s => (s.id === id ? { ...s, ...updated } : s)));
  };

  const deleteSurvey = (id: string) => {
    setSurveys(prev => prev.filter(s => s.id !== id));
  };

  const toggleSurveyActive = (id: string) => {
    setSurveys(prev => prev.map(s => (s.id === id ? { ...s, isActive: !s.isActive } : s)));
  };

  // Comments (Immediately visible & moderated)
  const addComment = (commentData: Omit<CommentItem, 'id' | 'createdAt' | 'status'> & { status?: CommentItem['status'] }) => {
    const now = new Date();
    const formatted = now.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const newComment: CommentItem = {
      ...commentData,
      id: `comm-${Date.now()}`,
      createdAt: formatted,
      visibility: commentData.visibility || 'public',
      status: commentData.status || 'published', // immediately visible, modifiable in admin
    };
    setComments(prev => [newComment, ...prev]);
  };

  const updateCommentStatus = (id: string, status: CommentItem['status'], adminReply?: string) => {
    setComments(prev =>
      prev.map(c => (c.id === id ? { ...c, status, adminReply: adminReply ?? c.adminReply } : c))
    );
  };

  const deleteComment = (id: string) => {
    setComments(prev => prev.filter(c => c.id !== id));
  };

  // Member Management Actions
  const registerMember = (data: { 
    name: string; 
    email: string; 
    role: UserRole; 
    facultyId?: string; 
    academicYear?: string;
    phone?: string;
  }) => {
    const isCitizen = data.role === 'citizen';
    const newMember: User = {
      id: `user-${Date.now()}`,
      name: data.name,
      email: data.email,
      role: data.role,
      facultyId: data.facultyId,
      academicYear: data.academicYear,
      phone: data.phone,
      isVerified: isCitizen,
      status: isCitizen ? 'approved' : 'pending',
      joinedAt: 'À l’instant',
    };
    setMembers(prev => [newMember, ...prev]);
    setCurrentUser(newMember);
  };

  const addMember = (memberData: Omit<User, 'id' | 'joinedAt'>) => {
    const newMember: User = {
      ...memberData,
      id: `user-${Date.now()}`,
      joinedAt: 'Créé par l’admin',
    };
    setMembers(prev => [newMember, ...prev]);
  };

  const editMember = (id: string, updated: Partial<User>) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, ...updated } : m));
    if (currentUser && currentUser.id === id) {
      setCurrentUser(prev => prev ? { ...prev, ...updated } : null);
    }
  };

  const approveMember = (userId: string) => {
    setMembers(prev => prev.map(m => m.id === userId ? { ...m, isVerified: true, status: 'approved' } : m));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(prev => prev ? { ...prev, isVerified: true, status: 'approved' } : null);
    }
  };

  const rejectMember = (userId: string) => {
    setMembers(prev => prev.map(m => m.id === userId ? { ...m, isVerified: false, status: 'rejected' } : m));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(prev => prev ? { ...prev, isVerified: false, status: 'rejected' } : null);
    }
  };

  const deleteMember = (userId: string) => {
    setMembers(prev => prev.filter(m => m.id !== userId));
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(null);
    }
  };

  // Authentication
  const login = (email: string, _password?: string) => {
    const found = members.find(m => m.email.toLowerCase() === email.trim().toLowerCase());
    if (found) {
      setCurrentUser(found);
      setIsAuthModalOpen(false);
      return true;
    }
    // If not found in members, register as a citizen or quick user
    const quickUser: User = {
      id: `user-${Date.now()}`,
      name: email.split('@')[0],
      email: email.trim(),
      role: 'citizen',
      isVerified: true,
      status: 'approved',
      joinedAt: 'Aujourd’hui',
    };
    setMembers(prev => [quickUser, ...prev]);
    setCurrentUser(quickUser);
    setIsAuthModalOpen(false);
    return true;
  };

  const loginAsDemoUser = (type: 'student' | 'doctor' | 'citizen' | 'admin') => {
    if (type === 'student') {
      setCurrentUser({
        id: 'user-demo-student',
        name: 'Kofi Mawuli Mensah',
        email: 'kofi.mensah@fss.univ-lome.tg',
        role: 'student',
        facultyId: 'FSS-PHARM-2022-014',
        academicYear: '5ème Année Pharmacie',
        isVerified: true,
        status: 'approved',
        joinedAt: '01 Octobre 2025',
        phone: '+228 90 12 34 56',
      });
    } else if (type === 'doctor') {
      setCurrentUser({
        id: 'user-demo-doctor',
        name: 'Dr. Ayélé Akossiwa Lawson',
        email: 'dr.ayele.lawson@onpt.tg',
        role: 'doctor',
        facultyId: 'ORDRE-PHARM-TG-2023-088',
        academicYear: 'Diplômée FSS Lomé (2023)',
        isVerified: true,
        status: 'approved',
        joinedAt: '15 Septembre 2025',
        phone: '+228 91 87 65 43',
      });
    } else if (type === 'admin') {
      setCurrentUser({
        id: 'user-demo-admin',
        name: 'Président Bureau AEPHAT',
        email: 'president@aephat.tg',
        role: 'admin',
        facultyId: 'BUREAU-EXEC-2026',
        academicYear: 'Direction Exécutive',
        isVerified: true,
        status: 'approved',
        joinedAt: 'Mandat 2025-2026',
        phone: '+228 90 00 11 22',
      });
      setIsAdminMode(true);
    } else {
      setCurrentUser({
        id: 'user-demo-citizen',
        name: 'Ablam Doe',
        email: 'ablam.doe@gmail.com',
        role: 'citizen',
        isVerified: true,
        status: 'approved',
        joinedAt: '12 Janvier 2026',
        phone: '+228 96 55 44 33',
      });
    }
    setIsAuthModalOpen(false);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const t = translations[language];

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isAdminMode,
        setIsAdminMode,
        adminRole,
        setAdminRole,
        currentUser,
        setCurrentUser,
        login,
        loginAsDemoUser,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalTab,
        setAuthModalTab,
        posts,
        addPost,
        editPost,
        deletePost,
        likePost,
        publishPostNow,
        boardMembers,
        addBoardMember,
        editBoardMember,
        deleteBoardMember,
        healthArticles,
        addHealthArticle,
        deleteHealthArticle,
        lastHealthSyncTime,
        isSyncingHealth,
        syncHealthWithOmsAndVidal,
        surveys,
        addSurvey,
        editSurvey,
        deleteSurvey,
        toggleSurveyActive,
        comments,
        addComment,
        updateCommentStatus,
        deleteComment,
        activeCommentsPostId,
        setActiveCommentsPostId,
        members,
        registerMember,
        addMember,
        editMember,
        approveMember,
        rejectMember,
        deleteMember,
        activeCommentTarget,
        setActiveCommentTarget,
        activeStatsSurvey,
        setActiveStatsSurvey,
        activeReadArticle,
        setActiveReadArticle,
        activeReadPost,
        setActiveReadPost,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
