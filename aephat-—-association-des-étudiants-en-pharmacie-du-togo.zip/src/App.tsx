import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AssociationPosts } from './components/AssociationPosts';
import { HealthWire } from './components/HealthWire';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { AdminDashboard } from './components/AdminDashboard';
import { MemberAuthModal } from './components/MemberAuthModal';
import { CommentsModal } from './components/CommentsModal';
import { PrivateCommentModal } from './components/PrivateCommentModal';
import { SurveyStatsModal } from './components/SurveyStatsModal';
import { ArticleModal } from './components/ArticleModal';

const MainLayout: React.FC = () => {
  const { isAdminMode } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-emerald-600 selection:text-white">
      {isAdminMode ? (
        <AdminDashboard />
      ) : (
        <>
          <Navbar />
          <main className="flex-1">
            <Hero />
            {/* Unified Feed: Association Posts & In-Feed Opinion Polls */}
            <AssociationPosts />
            {/* Certified Health Wire: Automated Hourly OMS & VIDAL Ingestion */}
            <HealthWire />
            {/* Dynamic Board Executive & Institutional Values */}
            <AboutSection />
          </main>
          <Footer />
        </>
      )}

      {/* Global Interactive Modals */}
      <MemberAuthModal />
      <CommentsModal />
      <PrivateCommentModal />
      <SurveyStatsModal />
      <ArticleModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
