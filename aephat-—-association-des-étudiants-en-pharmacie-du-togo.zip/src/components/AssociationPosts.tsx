import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Post, PostCategory, Survey } from '../types';
import { 
  Heart, 
  MessageSquare, 
  Share2, 
  Calendar, 
  User, 
  Trash2, 
  Sparkles,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Vote,
  BarChart3,
  Mail,
  Clock,
  ShieldCheck,
  Send
} from 'lucide-react';

export const AssociationPosts: React.FC = () => {
  const { 
    posts, 
    surveys,
    comments,
    likePost, 
    deletePost, 
    language, 
    t, 
    isAdminMode, 
    setActiveReadPost,
    setActiveCommentsPostId,
    setActiveStatsSurvey
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | PostCategory | 'surveys'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filters: { key: 'all' | PostCategory | 'surveys'; label: string }[] = [
    { key: 'all', label: t.posts.filterAll },
    { key: 'evenement', label: t.posts.filterEvents },
    { key: 'academique', label: t.posts.filterAcademic },
    { key: 'humanitaire', label: t.posts.filterHumanitarian },
    { key: 'vie_etudiante', label: t.posts.filterStudentLife },
    { key: 'surveys', label: t.posts.filterSurveys },
  ];

  // In public mode, only show published posts (or scheduled posts if their date has passed)
  const visiblePosts = posts.filter(post => {
    if (isAdminMode) return true;
    if (post.status === 'draft') return false;
    if (post.status === 'scheduled' && post.scheduledDate) {
      return new Date(post.scheduledDate).getTime() <= Date.now();
    }
    return post.status === 'published';
  });

  // Combine posts and surveys in the unified feed
  type FeedItem = 
    | { type: 'post'; data: Post }
    | { type: 'survey'; data: Survey };

  const feedItems: FeedItem[] = [];

  if (activeFilter !== 'surveys') {
    visiblePosts
      .filter(p => activeFilter === 'all' ? true : p.category === activeFilter)
      .forEach(p => feedItems.push({ type: 'post', data: p }));
  }

  if (activeFilter === 'all' || activeFilter === 'surveys') {
    surveys
      .filter(s => s.isActive)
      .forEach(s => feedItems.push({ type: 'survey', data: s }));
  }

  const handleShare = (id: string, isSurvey?: boolean) => {
    const url = `${window.location.origin}#${isSurvey ? 'survey' : 'post'}-${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getCategoryBadgeClass = (cat: PostCategory) => {
    switch (cat) {
      case 'evenement':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'humanitaire':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'academique':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'vie_etudiante':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <section id="association-life" className="py-20 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100/80 px-3 py-1 rounded-full border border-emerald-200">
              <Sparkles className="w-3.5 h-3.5" />
              {t.posts.badge}
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-heading tracking-tight">
              {t.posts.title}
            </h2>
            <p className="text-base text-slate-600 mt-2 leading-relaxed">
              {t.posts.subtitle}
            </p>
          </div>

          {/* Categories & Survey Filter Bar */}
          <div className="flex flex-wrap items-center gap-2">
            {filters.map((flt) => (
              <button
                key={flt.key}
                onClick={() => setActiveFilter(flt.key)}
                className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  activeFilter === flt.key
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 hover:bg-slate-200/70 border border-slate-200'
                }`}
              >
                {flt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Posts & Surveys Unified Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {feedItems.map((item) => {
            if (item.type === 'survey') {
              const survey = item.data;
              const surveyCommentsCount = comments.filter(c => c.targetId === survey.id && c.status !== 'hidden').length;

              return (
                <article
                  key={`survey-${survey.id}`}
                  id={`survey-${survey.id}`}
                  className="group flex flex-col justify-between bg-gradient-to-b from-teal-50/50 via-white to-white rounded-2xl border-2 border-teal-500/30 overflow-hidden shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 p-6"
                >
                  <div>
                    {/* Survey Top Badge */}
                    <div className="flex items-center justify-between gap-2 mb-4">
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg uppercase tracking-wide bg-teal-100 text-teal-800 border border-teal-200">
                        <Vote className="w-3.5 h-3.5 text-teal-700" />
                        <span>Sondage Direct</span>
                      </span>
                      <span className="text-[11px] text-slate-400 font-medium">
                        Échéance : {survey.deadline}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors leading-snug">
                      {survey.title[language]}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                      {survey.description[language]}
                    </p>

                    {/* Survey Access Rule Badge */}
                    <div className="mt-4 p-2.5 rounded-xl bg-slate-100/80 border border-slate-200 text-xs flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0" />
                      <span className="text-slate-700 text-[11px]">
                        {survey.restriction === 'verified_only'
                          ? t.surveys.ruleVerifiedOnly
                          : t.surveys.ruleAllWithEmail}
                      </span>
                    </div>

                    {/* Google Form Associated Mail */}
                    <div className="mt-2.5 p-2 rounded-lg bg-teal-50/60 border border-teal-200/80 text-[11px] text-teal-900 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span className="font-medium truncate">
                        Gestionnaire : <strong className="font-semibold">{survey.resultsAccessEmail}</strong>
                      </span>
                    </div>

                    {/* Results Progress Preview */}
                    <div className="mt-4 space-y-1.5">
                      <div className="flex justify-between text-[11px] font-semibold text-slate-600">
                        <span>Tendance des votes ({survey.responsesCount} participants)</span>
                        <span className="text-teal-700 font-bold">{survey.resultsSummary.options[0]?.percent || 50}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div 
                          className="h-full bg-teal-600 rounded-full" 
                          style={{ width: `${survey.resultsSummary.options[0]?.percent || 50}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Survey Controls Footer */}
                  <div className="pt-5 mt-6 border-t border-slate-100 flex flex-col gap-3">
                    <div className="flex items-center justify-between gap-2">
                      <a
                        href={survey.googleFormUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-2 px-3 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{t.surveys.btnParticipate}</span>
                      </a>

                      <button
                        onClick={() => setActiveStatsSurvey(survey)}
                        className="p-2 text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                        title={t.surveys.btnViewStats}
                      >
                        <BarChart3 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setActiveCommentsPostId(survey.id)}
                        className="p-2 text-slate-600 hover:text-teal-700 bg-slate-100 hover:bg-slate-200/70 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Commentaires du sondage"
                      >
                        <MessageSquare className="w-4 h-4 text-teal-600" />
                        <span>{surveyCommentsCount}</span>
                      </button>

                      <button
                        onClick={() => handleShare(survey.id, true)}
                        className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
                        title="Partager"
                      >
                        {copiedId === survey.id ? (
                          <CheckCircle2 className="w-4 h-4 text-teal-600" />
                        ) : (
                          <Share2 className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </article>
              );
            }

            // Standard Post item
            const post = item.data;
            const postCommentsCount = comments.filter(c => c.targetId === post.id && c.status !== 'hidden').length;

            return (
              <article 
                key={post.id} 
                id={`post-${post.id}`}
                className="group flex flex-col bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              >
                {/* Card Image */}
                {post.imageUrl && (
                  <div className="relative h-52 w-full overflow-hidden bg-slate-100 cursor-pointer" onClick={() => setActiveReadPost(post)}>
                    <img
                      src={post.imageUrl}
                      alt={post.title[language]}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3">
                      <span className={`text-[11px] font-bold px-2.5 py-1 rounded-lg uppercase tracking-wide border shadow-xs ${getCategoryBadgeClass(post.category)}`}>
                        {post.category}
                      </span>
                    </div>

                    {/* Status badge if scheduled or test */}
                    {post.status === 'scheduled' && (
                      <div className="absolute top-3 right-3 flex items-center gap-1 bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
                        <Clock className="w-3 h-3" />
                        <span>Programmé</span>
                      </div>
                    )}

                    {post.isTestPost && post.status !== 'scheduled' && (
                      <div className="absolute top-3 right-3 flex items-center gap-1 bg-blue-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
                        <AlertCircle className="w-3 h-3" />
                        <span>Test Post</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Meta date & author */}
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-1 max-w-[150px] truncate text-slate-600 font-medium">
                        <User className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="truncate">{post.author.split(' ')[0]}</span>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 
                      onClick={() => setActiveReadPost(post)}
                      className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors leading-snug cursor-pointer line-clamp-2"
                    >
                      {post.title[language]}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-sm text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                      {post.excerpt[language]}
                    </p>

                    {/* Scheduled notice for admins */}
                    {post.status === 'scheduled' && post.scheduledDate && (
                      <div className="mt-3 p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px] flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span>Publication programmée pour le {new Date(post.scheduledDate).toLocaleString()}</span>
                      </div>
                    )}

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 mt-4">
                      {post.tags.map((tag) => (
                        <span key={tag} className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Card Footer: Likes, Comments Click, Share & Admin Delete */}
                  <div className="pt-5 mt-6 border-t border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {/* Like button */}
                      <button
                        onClick={() => likePost(post.id)}
                        className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 transition-colors"
                        title={t.posts.likeAction}
                      >
                        <Heart className={`w-4 h-4 ${post.likes > 0 ? 'text-rose-500 fill-rose-500' : 'text-slate-400'}`} />
                        <span>{post.likes}</span>
                      </button>

                      {/* Comment button with count - Opens CommentsModal */}
                      <button
                        onClick={() => setActiveCommentsPostId(post.id)}
                        className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-emerald-700 transition-colors"
                        title="Voir et ajouter des commentaires"
                      >
                        <MessageSquare className="w-4 h-4 text-emerald-600" />
                        <span>{postCommentsCount}</span>
                        <span className="hidden sm:inline text-[11px] text-slate-400">commentaires</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Share action */}
                      <button
                        onClick={() => handleShare(post.id)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                        title="Copier le lien"
                      >
                        {copiedId === post.id ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Share2 className="w-4 h-4" />
                        )}
                      </button>

                      {/* Quick Delete in Admin Mode */}
                      {isAdminMode && (
                        <button
                          onClick={() => {
                            if (confirm(t.admin.deleteConfirm)) {
                              deletePost(post.id);
                            }
                          }}
                          className="p-1.5 text-rose-500 hover:text-rose-700 rounded-lg hover:bg-rose-50 transition-colors"
                          title="Supprimer la publication"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        onClick={() => setActiveReadPost(post)}
                        className="text-xs font-bold text-emerald-700 hover:text-emerald-800 ml-1"
                      >
                        {language === 'fr' ? 'Lire →' : 'Read →'}
                      </button>
                    </div>
                  </div>

                </div>
              </article>
            );
          })}
        </div>

      </div>
    </section>
  );
};
