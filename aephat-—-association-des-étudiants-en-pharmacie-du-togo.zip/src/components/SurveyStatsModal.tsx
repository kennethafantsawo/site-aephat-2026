import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  BarChart3, 
  Users, 
  Calendar, 
  ExternalLink, 
  FileSpreadsheet, 
  CheckCircle2,
  Share2
} from 'lucide-react';

export const SurveyStatsModal: React.FC = () => {
  const { 
    activeStatsSurvey, 
    setActiveStatsSurvey, 
    language, 
    t 
  } = useApp();

  if (!activeStatsSurvey) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={() => setActiveStatsSurvey(null)}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
            <BarChart3 className="w-3.5 h-3.5" />
            <span>{t.surveys.statsModalTitle}</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-2 font-heading">
            {activeStatsSurvey.title[language]}
          </h3>
          <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
            <span className="flex items-center gap-1 font-bold text-slate-800">
              <Users className="w-3.5 h-3.5 text-emerald-600" />
              {activeStatsSurvey.responsesCount} {t.surveys.statsTotalVotes}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Clôture : {activeStatsSurvey.deadline}
            </span>
          </div>
        </div>

        {/* Options Breakdown Bars */}
        <div className="space-y-4 mb-6">
          {activeStatsSurvey.resultsSummary.options.map((option, idx) => (
            <div key={option.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-sm font-semibold text-slate-900 leading-snug">
                    {option.label[language]}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-base font-black text-emerald-700">
                    {option.percent}%
                  </span>
                  <p className="text-[10px] text-slate-400">
                    {option.votesCount} {language === 'fr' ? 'voix' : 'votes'}
                  </p>
                </div>
              </div>

              {/* Progress track */}
              <div className="h-3 w-full bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 rounded-full transition-all duration-700"
                  style={{ width: `${option.percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Live Sync Notice */}
        <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2 mb-6">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
          <p>{t.surveys.statsModalDisclaimer}</p>
        </div>

        {/* Action Links */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200 text-xs">
          <a
            href={activeStatsSurvey.googleSpreadsheetStatsUrl || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-emerald-700 font-bold hover:underline"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{language === 'fr' ? 'Consulter le tableau Google Sheets brut' : 'Open raw Google Sheets records'}</span>
          </a>

          <button
            onClick={() => setActiveStatsSurvey(null)}
            className="px-5 py-2 rounded-xl bg-slate-900 text-white font-bold hover:bg-slate-800 transition-colors"
          >
            {language === 'fr' ? 'Fermer' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
