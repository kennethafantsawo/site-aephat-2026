import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Calendar, 
  User, 
  ExternalLink, 
  Building2, 
  CheckCircle, 
  Clock, 
  MessageSquareLock,
  Heart
} from 'lucide-react';

export const ArticleModal: React.FC = () => {
  const { 
    activeReadArticle, 
    setActiveReadArticle, 
    activeReadPost, 
    setActiveReadPost, 
    language, 
    t, 
    likePost,
    setActiveCommentTarget 
  } = useApp();

  if (!activeReadArticle && !activeReadPost) return null;

  const handleClose = () => {
    setActiveReadArticle(null);
    setActiveReadPost(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close */}
        <button
          onClick={handleClose}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* HEALTH ARTICLE VIEW */}
        {activeReadArticle && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800 bg-teal-100 px-2.5 py-0.5 rounded">
                {activeReadArticle.category}
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500">{activeReadArticle.publishDate}</span>
            </div>

            <h2 className="text-2xl font-bold text-slate-900 leading-tight font-heading">
              {activeReadArticle.title[language]}
            </h2>

            {/* Official Source Box */}
            <div className="my-5 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-slate-700 mb-1">
                <Building2 className="w-4 h-4 text-teal-700" />
                <span>Source officielle certifiée :</span>
              </div>
              <p className="font-semibold text-slate-900 text-sm">{activeReadArticle.source}</p>
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60">
                <span className="text-emerald-700 flex items-center gap-1 font-medium">
                  <CheckCircle className="w-3.5 h-3.5" />
                  {activeReadArticle.verifiedBy}
                </span>
                <a
                  href={activeReadArticle.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-teal-700 font-bold hover:underline flex items-center gap-1"
                >
                  <span>Accéder à la source</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="prose prose-slate text-sm leading-relaxed text-slate-700 space-y-4">
              <p className="font-semibold text-slate-900 text-base">
                {activeReadArticle.summary[language]}
              </p>
              <p>
                {activeReadArticle.content[language]}
              </p>
            </div>

            <div className="mt-8 pt-5 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => {
                  const target = activeReadArticle;
                  handleClose();
                  setActiveCommentTarget({
                    type: 'suggestion',
                    id: target.id,
                    title: target.title[language],
                  });
                }}
                className="text-xs font-semibold text-teal-800 hover:text-teal-950 flex items-center gap-1.5"
              >
                <MessageSquareLock className="w-4 h-4" />
                <span>Poser une question médicale aux pharmaciens AEPHAT</span>
              </button>

              <button
                onClick={handleClose}
                className="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
              >
                Fermer
              </button>
            </div>
          </div>
        )}

        {/* ASSOCIATION POST VIEW */}
        {activeReadPost && (
          <div>
            {activeReadPost.imageUrl && (
              <div className="h-60 -mx-6 -mt-6 sm:-mx-8 sm:-mt-8 mb-6 overflow-hidden rounded-t-2xl">
                <img 
                  src={activeReadPost.imageUrl} 
                  alt={activeReadPost.title[language]} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            <div className="flex items-center gap-2 mb-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
                {activeReadPost.category}
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500">{activeReadPost.date}</span>
            </div>

            <h2 className="text-2xl font-bold text-slate-900 leading-tight font-heading">
              {activeReadPost.title[language]}
            </h2>

            <div className="flex items-center gap-2 text-xs text-slate-500 mt-2 mb-6">
              <User className="w-3.5 h-3.5 text-emerald-600" />
              <span>{activeReadPost.author} ({activeReadPost.authorRole})</span>
            </div>

            <div className="prose prose-slate text-sm leading-relaxed text-slate-700 space-y-4">
              <p className="font-semibold text-slate-900 text-base">
                {activeReadPost.excerpt[language]}
              </p>
              <p>
                {activeReadPost.content[language]}
              </p>
            </div>

            <div className="mt-8 pt-5 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => likePost(activeReadPost.id)}
                  className="flex items-center gap-1.5 text-xs font-bold text-rose-600 bg-rose-50 px-3 py-1.5 rounded-lg"
                >
                  <Heart className="w-4 h-4 fill-rose-500" />
                  <span>{activeReadPost.likes} J'aime</span>
                </button>

                <button
                  onClick={() => {
                    const target = activeReadPost;
                    handleClose();
                    setActiveCommentTarget({
                      type: 'post',
                      id: target.id,
                      title: target.title[language],
                    });
                  }}
                  className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1.5"
                >
                  <MessageSquareLock className="w-4 h-4" />
                  <span>Commenter en privé</span>
                </button>
              </div>

              <button
                onClick={handleClose}
                className="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl"
              >
                Fermer
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
