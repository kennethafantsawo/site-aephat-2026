import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  ArrowRight, 
  Users, 
  Activity, 
  BookOpenCheck, 
  ShieldCheck,
  Building2,
  Calendar
} from 'lucide-react';
import heroImg from '../assets/images/aephat_hero_1788703827940.jpg';

export const Hero: React.FC = () => {
  const { t, language, setIsAuthModalOpen } = useApp();

  return (
    <section id="home" className="relative overflow-hidden bg-radial from-slate-900 via-slate-900 to-slate-950 text-white pt-12 pb-20 lg:pt-16 lg:pb-28">
      {/* Subtle Background Glows */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Text & CTA */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            
            {/* National & Academic Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs font-medium w-fit">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>{t.hero.badge}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-[1.15] text-slate-100 font-heading">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300">
                {t.hero.titleHighlight}
              </span>{' '}
              <br className="hidden sm:inline" />
              {t.hero.titleMain}
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              {t.hero.description}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <a
                href="#association-life"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm sm:text-base shadow-lg shadow-emerald-950/50 hover:shadow-emerald-600/30 transition-all group"
              >
                <span>{t.hero.btnDiscover}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700/80 font-semibold text-sm sm:text-base transition-all"
              >
                <Users className="w-4 h-4 text-amber-400" />
                <span>{t.hero.btnJoin}</span>
              </button>
            </div>

            {/* Institutional Endorsement micro-banner */}
            <div className="pt-4 flex items-center gap-4 text-xs text-slate-400 border-t border-slate-800/70">
              <div className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>Faculté des Sciences de la Santé</span>
              </div>
              <span className="text-slate-600">•</span>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Affiliée IPSF & ONPT</span>
              </div>
            </div>

          </div>

          {/* Right Column: Dynamic Photography & Live Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Photo Card */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-slate-700/50 group">
                <img
                  src={heroImg}
                  alt="Étudiants en Pharmacie du Togo"
                  className="w-full h-80 sm:h-96 object-cover transform group-hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent pointer-events-none" />

                {/* Overlaid Pill Badge */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                      <Activity className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-100">
                        {language === 'fr' ? 'Campagne Nationale 2026' : 'National Health Campaign 2026'}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {language === 'fr' ? 'Dépistage & Éducation Thérapeutique' : 'Screening & Health Literacy'}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase font-black px-2 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    En cours
                  </span>
                </div>
              </div>

              {/* Floating Stat Widget */}
              <div className="hidden sm:flex absolute -bottom-6 -left-6 bg-white text-slate-900 p-4 rounded-xl shadow-xl border border-slate-100 items-center gap-3 animate-fade-in">
                <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-800">
                  <BookOpenCheck className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-lg font-extrabold text-slate-900 leading-none">650+</p>
                  <p className="text-[11px] font-medium text-slate-500 mt-0.5">
                    {language === 'fr' ? 'Futurs Pharmaciens Unis' : 'United Future Pharmacists'}
                  </p>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Association Key Numbers Grid */}
        <div className="mt-16 pt-10 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex flex-col space-y-1">
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-heading">650+</span>
            <span className="text-xs sm:text-sm text-slate-400 font-medium">{t.hero.statsStudents}</span>
          </div>
          <div className="flex flex-col space-y-1">
            <span className="text-2xl sm:text-3xl font-black text-amber-400 font-heading">14</span>
            <span className="text-xs sm:text-sm text-slate-400 font-medium">{t.hero.statsCampaigns}</span>
          </div>
          <div className="flex flex-col space-y-1">
            <span className="text-2xl sm:text-3xl font-black text-teal-400 font-heading">100%</span>
            <span className="text-xs sm:text-sm text-slate-400 font-medium">{t.hero.statsArticles}</span>
          </div>
          <div className="flex flex-col space-y-1">
            <span className="text-2xl sm:text-3xl font-black text-emerald-300 font-heading">98.5%</span>
            <span className="text-xs sm:text-sm text-slate-400 font-medium">{t.hero.statsSatisfaction}</span>
          </div>
        </div>

      </div>
    </section>
  );
};
