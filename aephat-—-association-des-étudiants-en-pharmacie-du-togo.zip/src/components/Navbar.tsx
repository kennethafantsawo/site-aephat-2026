import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Menu, 
  X, 
  Globe, 
  ShieldCheck, 
  UserCheck, 
  LogOut, 
  KeyRound, 
  ChevronDown,
  LogIn,
  UserPlus
} from 'lucide-react';
import logoImg from '../assets/images/aephat_logo_1788703808100.jpg';

export const Navbar: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    t, 
    currentUser, 
    logout, 
    setIsAuthModalOpen, 
    setAuthModalTab,
    isAdminMode, 
    setIsAdminMode
  } = useApp();
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);

  const navLinks = [
    { href: '#home', label: t.nav.home },
    { href: '#association-life', label: t.nav.associationLife },
    { href: '#health-wire', label: t.nav.healthWire },
    { href: '#about', label: t.nav.about },
  ];

  const handleOpenAuth = (tab: 'login' | 'register') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top micro-bar: Togo health notice & discreet sub-domain indicator */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-medium text-slate-200">
              {language === 'fr' 
                ? 'Portail Officiel • Université de Lomé - Faculté des Sciences de la Santé (FSS)' 
                : 'Official Portal • University of Lomé - Faculty of Health Sciences (FSS)'}
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-slate-400 hidden md:inline">
              Lomé, Togo
            </span>
            {/* Discreet Admin Entrance */}
            <button
              onClick={() => setIsAdminMode(!isAdminMode)}
              className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-medium transition-colors ${
                isAdminMode 
                  ? 'bg-amber-500 text-slate-950 font-bold' 
                  : 'text-slate-400 hover:text-amber-300 hover:bg-slate-800'
              }`}
              title="Accès au sous-domaine d'administration admin.aephat.tg"
            >
              <KeyRound className="w-3 h-3" />
              <span>{isAdminMode ? 'Mode Admin (admin.aephat.tg)' : 'Portail Bureau'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand Identity */}
          <a href="#home" className="flex items-center gap-3.5 group">
            <div className="relative w-12 h-12 rounded-xl overflow-hidden shadow-xs border border-emerald-500/20 bg-emerald-50 flex items-center justify-center">
              <img 
                src={logoImg} 
                alt="AEPHAT Logo" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black tracking-tight text-slate-900 font-heading">
                  AEPHAT
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 rounded">
                  Togo
                </span>
              </div>
              <span className="text-[11px] text-slate-500 font-medium hidden sm:block max-w-[280px] truncate leading-tight">
                Assoc. des Étudiants en Pharmacie
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-3.5 py-2 text-sm font-medium text-slate-600 hover:text-emerald-700 hover:bg-slate-100/70 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action Buttons: Language, Login, Register, Admin Exit */}
          <div className="hidden sm:flex items-center gap-2.5">
            
            {/* Language Switcher Dropdown */}
            <div className="relative mr-1">
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors border border-slate-200/60"
              >
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                <span className="uppercase">{language}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isLangDropdownOpen && (
                <div className="absolute right-0 mt-1 w-32 bg-white rounded-lg shadow-lg border border-slate-200 py-1 z-50">
                  <button
                    onClick={() => { setLanguage('fr'); setIsLangDropdownOpen(false); }}
                    className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-50 ${language === 'fr' ? 'text-emerald-600 font-bold bg-emerald-50/50' : 'text-slate-700'}`}
                  >
                    <span>Français</span>
                    {language === 'fr' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </button>
                  <button
                    onClick={() => { setLanguage('en'); setIsLangDropdownOpen(false); }}
                    className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-50 ${language === 'en' ? 'text-emerald-600 font-bold bg-emerald-50/50' : 'text-slate-700'}`}
                  >
                    <span>English</span>
                    {language === 'en' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </button>
                </div>
              )}
            </div>

            {/* Member User Status OR Explicit "Se connecter" and "S'inscrire" buttons */}
            {currentUser ? (
              <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200/80 rounded-xl px-3 py-1.5">
                <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="flex flex-col text-left">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold text-slate-900 leading-tight max-w-[120px] truncate">
                      {currentUser.name.split(' ')[0]}
                    </span>
                    {currentUser.isVerified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" title="Compte Vérifié AEPHAT" />
                    )}
                  </div>
                  <span className="text-[10px] text-emerald-700 capitalize font-medium">
                    {currentUser.role === 'student' ? 'Étudiant FSS' : currentUser.role === 'doctor' ? 'Dr. Pharmacie' : 'Membre'}
                  </span>
                </div>
                <button
                  onClick={logout}
                  className="p-1 hover:bg-emerald-100 rounded text-slate-500 hover:text-slate-800 transition-colors ml-1"
                  title={t.nav.logout}
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {/* Explicit "Se connecter" button */}
                <button
                  onClick={() => handleOpenAuth('login')}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 hover:text-emerald-800 hover:bg-slate-100 rounded-xl border border-slate-200 transition-all"
                >
                  <LogIn className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t.nav.login}</span>
                </button>

                {/* Explicit "S'inscrire" button */}
                <button
                  onClick={() => handleOpenAuth('register')}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs hover:shadow transition-all"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{t.nav.register}</span>
                </button>
              </div>
            )}

            {/* Quick Exit Admin button if in admin mode */}
            {isAdminMode && (
              <button
                onClick={() => setIsAdminMode(false)}
                className="px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-200 hover:bg-amber-300 border border-amber-400 rounded-xl transition-colors ml-1"
              >
                {t.admin.exitAdmin}
              </button>
            )}
          </div>

          {/* Mobile menu trigger */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => setLanguage(language === 'fr' ? 'en' : 'fr')}
              className="p-2 text-xs font-bold text-slate-700 bg-slate-100 rounded-lg"
            >
              {language.toUpperCase()}
            </button>
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2.5 rounded-lg text-slate-700 hover:bg-slate-100"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-xl">
          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-3 py-2 text-base font-medium text-slate-700 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            {currentUser ? (
              <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-xl">
                <div>
                  <p className="font-bold text-sm text-slate-900">{currentUser.name}</p>
                  <p className="text-xs text-emerald-700">{currentUser.email}</p>
                </div>
                <button
                  onClick={() => { logout(); setIsMobileMenuOpen(false); }}
                  className="px-3 py-1 text-xs font-semibold text-rose-600 bg-rose-50 rounded-lg"
                >
                  {t.nav.logout}
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => handleOpenAuth('login')}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  <LogIn className="w-4 h-4 text-emerald-600" />
                  <span>{t.nav.login}</span>
                </button>
                <button
                  onClick={() => handleOpenAuth('register')}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{t.nav.register}</span>
                </button>
              </div>
            )}

            <button
              onClick={() => { setIsAdminMode(!isAdminMode); setIsMobileMenuOpen(false); }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-600" />
              <span>{isAdminMode ? t.admin.exitAdmin : t.nav.adminPortal}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
