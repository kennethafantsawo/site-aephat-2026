import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Building, 
  Target, 
  Award, 
  HeartHandshake, 
  GraduationCap, 
  Mail, 
  Phone, 
  MessageCircle,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  PlusCircle,
  Users
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { language, t, boardMembers, isAdminMode, setIsAdminMode } = useApp();

  const institutionalValues = [
    {
      icon: Award,
      title: language === 'fr' ? 'Excellence Académique' : 'Academic Excellence',
      description: language === 'fr' 
        ? 'Organisation de tutorats galéniques, concours de pharmacologie et soutien continu aux étudiants de la 1ère à la 6ème année.'
        : 'Organizing galenics tutoring, pharmacology competitions, and academic assistance across all pharmacy cohorts.',
    },
    {
      icon: Target,
      title: language === 'fr' ? 'Éthique & Déontologie' : 'Ethics & Deontology',
      description: language === 'fr'
        ? 'Alignement rigoureux avec les standards de l’Ordre National des Pharmaciens du Togo et lutte contre la contrefaçon des médicaments.'
        : 'Strict adherence to national pharmaceutical standards and proactive engagement against falsified medical products.',
    },
    {
      icon: HeartHandshake,
      title: language === 'fr' ? 'Santé Communautaire' : 'Community Health',
      description: language === 'fr'
        ? 'Campagnes gratuites de dépistage du diabète et de l’HTA dans les marchés et cantons ruraux du Togo.'
        : 'Free community screening drives for hypertension and diabetes across local markets and rural districts.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-200">
            <Building className="w-3.5 h-3.5 text-emerald-700" />
            <span>Institution & Gouvernance</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-heading tracking-tight">
            {language === 'fr' ? 'À propos de l’AEPHAT & Le Bureau Exécutif' : 'About AEPHAT & The Executive Board'}
          </h2>
          <p className="text-base text-slate-600 mt-3 leading-relaxed">
            {language === 'fr'
              ? 'Créée au sein de la Faculté des Sciences de la Santé (FSS) de l’Université de Lomé, l’AEPHAT est l’organe officiel unissant les futurs pharmaciens et jeunes docteurs togolais.'
              : 'Established within the Faculty of Health Sciences (FSS) of the University of Lomé, AEPHAT serves as the official body representing pharmacy students and recent alumni.'}
          </p>
        </div>

        {/* Section 1: Executive Board Grid (Dynamic from AppContext) */}
        <div className="mb-20">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded border border-teal-200">
                <Users className="w-3.5 h-3.5" />
                <span>{t.board.badge}</span>
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-2 font-heading">
                {t.board.title}
              </h3>
              <p className="text-sm text-slate-500 mt-1">
                {t.board.subtitle}
              </p>
            </div>

            {isAdminMode && (
              <button
                onClick={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors self-start sm:self-auto"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Modifier le bureau dans l'Admin</span>
              </button>
            )}
          </div>

          {/* Board Members Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {boardMembers.map((member) => (
              <div
                key={member.id}
                className="group flex flex-col justify-between bg-slate-50 rounded-2xl border border-slate-200/90 overflow-hidden hover:bg-white hover:border-emerald-300 hover:shadow-xl transition-all duration-300"
              >
                <div className="p-6">
                  {/* Photo & Role Header */}
                  <div className="flex items-center gap-4 mb-4">
                    <div className="relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-emerald-500/30 bg-emerald-100 shrink-0 shadow-xs">
                      {member.photoUrl ? (
                        <img 
                          src={member.photoUrl} 
                          alt={member.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-bold text-emerald-800 text-lg">
                          {member.name.charAt(0)}
                        </div>
                      )}
                    </div>

                    <div>
                      <h4 className="text-base font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                        {member.name}
                      </h4>
                      <p className="text-xs font-bold text-emerald-700 mt-0.5">
                        {member.role[language]}
                      </p>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {member.level}
                      </p>
                    </div>
                  </div>

                  {/* Bio */}
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {member.bio[language]}
                  </p>
                </div>

                {/* Direct Contacts Action Bar: Call, WhatsApp, Email */}
                <div className="px-6 py-3.5 bg-white border-t border-slate-200/80 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Call Button */}
                    {member.phone && (
                      <a
                        href={`tel:${member.phone}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold text-slate-700 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 transition-colors"
                        title={`Appeler ${member.phone}`}
                      >
                        <Phone className="w-3 h-3 text-emerald-600" />
                        <span className="hidden sm:inline">{t.board.call}</span>
                      </a>
                    )}

                    {/* WhatsApp Button */}
                    {member.whatsapp && (
                      <a
                        href={`https://wa.me/${member.whatsapp.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold text-emerald-900 bg-emerald-100/70 hover:bg-emerald-200 transition-colors"
                        title={`Discuter sur WhatsApp (${member.whatsapp})`}
                      >
                        <MessageCircle className="w-3 h-3 text-emerald-700" />
                        <span>{t.board.whatsapp}</span>
                      </a>
                    )}
                  </div>

                  {/* Email Button */}
                  {member.email && (
                    <a
                      href={`mailto:${member.email}`}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-slate-500 hover:text-emerald-800 hover:bg-slate-100 transition-colors"
                      title={member.email}
                    >
                      <Mail className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="hidden md:inline truncate max-w-[110px]">{member.email}</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: Institutional Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12 border-t border-slate-200">
          {institutionalValues.map((val, idx) => {
            const Icon = val.icon;
            return (
              <div 
                key={idx} 
                className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:bg-white hover:border-emerald-300 hover:shadow-lg transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-slate-900 mb-2">
                  {val.title}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {val.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Section 3: Institutional Affiliations & Accreditation Banner */}
        <div className="mt-16 p-8 rounded-3xl bg-radial from-slate-900 to-slate-950 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded border border-emerald-800">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Agrément Officiel</span>
            </span>
            <h3 className="text-xl sm:text-2xl font-bold mt-2 font-heading">
              {language === 'fr' 
                ? 'Partenaire Clé du Système de Santé Togolais' 
                : 'Key Partner of the Togolese Health System'}
            </h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              {language === 'fr'
                ? 'L’AEPHAT collabore étroitement avec le Ministère de la Santé du Togo, l’Ordre National des Pharmaciens (ONPT), l’OMS Togo et l’IPSF pour promouvoir la sécurité du médicament et la formation d’excellence.'
                : 'AEPHAT collaborates closely with the Togo Ministry of Health, the National Order of Pharmacists (ONPT), WHO Togo, and IPSF to promote medicine safety and professional training.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="https://univ-lome.tg"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <span>FSS Université de Lomé</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </a>
            <a
              href="https://sante.gouv.tg"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <span>Ministère de la Santé</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
