import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Building2, 
  ExternalLink, 
  ShieldCheck, 
  KeyRound, 
  Heart,
  Globe
} from 'lucide-react';
import logoImg from '../assets/images/aephat_logo_1788703808100.jpg';

export const Footer: React.FC = () => {
  const { language, t, isAdminMode, setIsAdminMode } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Col 1 & 2: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden bg-white p-0.5 border border-emerald-500/30">
                <img src={logoImg} alt="AEPHAT" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div>
                <span className="text-xl font-black text-slate-100 font-heading tracking-tight">AEPHAT TOGO</span>
                <p className="text-[11px] text-emerald-400 font-medium">Association des Étudiants en Pharmacie du Togo</p>
              </div>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              {t.footer.aboutAEPHAT}
            </p>

            <div className="pt-2 flex items-center gap-3 text-slate-400">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="text-[11px]">Faculté des Sciences de la Santé • Université de Lomé</span>
            </div>
          </div>

          {/* Col 3: Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-slate-100 font-bold uppercase tracking-wider text-[11px]">
              {t.footer.quickLinks}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#home" className="hover:text-emerald-400 transition-colors">
                  {t.nav.home}
                </a>
              </li>
              <li>
                <a href="#association-life" className="hover:text-emerald-400 transition-colors">
                  {t.nav.associationLife}
                </a>
              </li>
              <li>
                <a href="#health-wire" className="hover:text-emerald-400 transition-colors">
                  {t.nav.healthWire}
                </a>
              </li>
              <li>
                <a href="#surveys" className="hover:text-emerald-400 transition-colors">
                  {t.nav.surveys}
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-emerald-400 transition-colors">
                  {t.nav.about}
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Partners */}
          <div className="space-y-3">
            <h4 className="text-slate-100 font-bold uppercase tracking-wider text-[11px]">
              {t.footer.officialPartners}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="https://univ-lome.tg" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                  <span>{t.footer.partnerFSS}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://onpt.tg" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                  <span>{t.footer.partnerONPT}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://sante.gouv.tg" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                  <span>{t.footer.partnerMinistry}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://www.afro.who.int/fr/countries/togo" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                  <span>{t.footer.partnerWHO}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://www.ipsf.org" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                  <span>{t.footer.partnerIPSF}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Administration & Confidentiality */}
          <div className="space-y-3">
            <h4 className="text-slate-100 font-bold uppercase tracking-wider text-[11px]">
              Sécurité & Déontologie
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-400">
              Les informations médicales sont fournies à titre indicatif et éducatif conformément aux recommandations des autorités togolaises et internationales.
            </p>

            <div className="pt-2">
              <button
                onClick={() => setIsAdminMode(!isAdminMode)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] font-semibold text-slate-300 border border-slate-800 transition-colors"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span>admin.aephat.tg</span>
              </button>
            </div>
          </div>

        </div>

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px]">
          <p>© {new Date().getFullYear()} {t.footer.copyright}</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>FSS Lomé • Togo</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Santé Publique & Recherche Galénique</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
