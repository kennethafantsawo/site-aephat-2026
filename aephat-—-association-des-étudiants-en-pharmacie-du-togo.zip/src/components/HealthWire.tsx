import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { HealthArticle, HealthCategory, HealthSource } from '../types';
import { 
  ShieldAlert, 
  ExternalLink, 
  Clock, 
  Calendar, 
  Building2, 
  CheckCircle, 
  BookOpen, 
  AlertTriangle,
  FileText,
  RotateCw,
  Sparkles,
  Globe2,
  Database
} from 'lucide-react';

export const HealthWire: React.FC = () => {
  const { 
    healthArticles, 
    language, 
    t, 
    setActiveReadArticle,
    setActiveCommentTarget,
    lastHealthSyncTime,
    isSyncingHealth,
    syncHealthWithOmsAndVidal
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | HealthSource | HealthCategory>('all');

  const filterOptions: { key: 'all' | HealthSource | HealthCategory; label: string }[] = [
    { key: 'all', label: t.health.filterAll },
    { key: 'VIDAL', label: 'VIDAL (Médicament & Sécurité)' },
    { key: 'OMS', label: 'OMS (Santé Mondiale)' },
    { key: 'pharmacovigilance', label: t.health.filterPharmacovigilance },
    { key: 'alerte', label: t.health.filterAlerts },
    { key: 'prevention', label: t.health.filterPrevention },
  ];

  const filteredArticles = healthArticles.filter(art => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'VIDAL' || activeFilter === 'OMS') {
      return art.sourceType === activeFilter;
    }
    return art.category === activeFilter;
  });

  const getSourceBadge = (sourceType: HealthSource) => {
    if (sourceType === 'VIDAL') {
      return {
        name: 'VIDAL France',
        classes: 'bg-amber-100 text-amber-900 border-amber-300',
        icon: Database,
      };
    }
    if (sourceType === 'OMS') {
      return {
        name: 'OMS / WHO',
        classes: 'bg-blue-100 text-blue-900 border-blue-300',
        icon: Globe2,
      };
    }
    return {
      name: 'Ministère Togo',
      classes: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      icon: Building2,
    };
  };

  const getCategoryTheme = (cat: HealthCategory) => {
    switch (cat) {
      case 'alerte':
        return {
          badge: 'bg-rose-100 text-rose-800 border-rose-200',
          icon: AlertTriangle,
        };
      case 'pharmacovigilance':
        return {
          badge: 'bg-amber-100 text-amber-800 border-amber-200',
          icon: ShieldAlert,
        };
      case 'prevention':
        return {
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          icon: CheckCircle,
        };
      case 'recherche':
        return {
          badge: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          icon: BookOpen,
        };
    }
  };

  return (
    <section id="health-wire" className="py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-800 bg-teal-100/90 px-3 py-1 rounded-full border border-teal-200">
              <ShieldAlert className="w-3.5 h-3.5 text-teal-700" />
              {t.health.badge}
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-heading tracking-tight">
              {t.health.title}
            </h2>
            <p className="text-base text-slate-600 mt-2 leading-relaxed">
              {t.health.subtitle}
            </p>
          </div>

          {/* Hourly Auto-Refresh Status & Manual Refresh Button */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 self-start md:self-end">
            <div className="text-xs text-slate-500 flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>{lastHealthSyncTime}</span>
            </div>

            <button
              onClick={() => syncHealthWithOmsAndVidal()}
              disabled={isSyncingHealth}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl text-teal-900 bg-teal-100 hover:bg-teal-200 border border-teal-300 transition-colors shadow-xs disabled:opacity-50"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isSyncingHealth ? 'animate-spin text-teal-700' : ''}`} />
              <span>{isSyncingHealth ? t.health.syncing : t.health.syncNow}</span>
            </button>
          </div>
        </div>

        {/* Theme & Source Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mb-10">
          {filterOptions.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setActiveFilter(opt.key)}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-all ${
                activeFilter === opt.key
                  ? 'bg-teal-900 text-white shadow-sm'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Health Briefs Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredArticles.map((art) => {
            const catTheme = getCategoryTheme(art.category);
            const srcTheme = getSourceBadge(art.sourceType);
            const CatIcon = catTheme.icon;
            const SrcIcon = srcTheme.icon;

            return (
              <div 
                key={art.id}
                className="flex flex-col justify-between bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-xl hover:border-teal-400 transition-all duration-300"
              >
                <div>
                  {/* Category and Source Badge */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <div className="flex items-center gap-1.5">
                      <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide border ${srcTheme.classes}`}>
                        <SrcIcon className="w-3 h-3" />
                        <span>{srcTheme.name}</span>
                      </span>
                      <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide border ${catTheme.badge}`}>
                        <CatIcon className="w-3 h-3" />
                        <span>{art.category}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span>{art.readTimeMinutes} {t.health.readMinutes}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 
                    onClick={() => setActiveReadArticle(art)}
                    className="text-lg font-bold text-slate-900 hover:text-teal-700 transition-colors cursor-pointer leading-snug line-clamp-2"
                  >
                    {art.title[language]}
                  </h3>

                  {/* Summary */}
                  <p className="text-sm text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                    {art.summary[language]}
                  </p>

                  {/* Official Source Attribution Box */}
                  <div className="mt-5 p-3 rounded-xl bg-slate-50 border border-slate-200/90 text-xs">
                    <div className="flex items-center justify-between text-slate-500 font-semibold mb-1">
                      <div className="flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-teal-700" />
                        <span>{t.health.officialSourcePrefix}</span>
                      </div>
                      {art.importedAt && (
                        <span className="text-[10px] text-teal-700 font-medium">{art.importedAt}</span>
                      )}
                    </div>
                    <p className="font-bold text-slate-800 truncate">{art.source}</p>
                    <p className="text-[11px] text-emerald-700 flex items-center gap-1 mt-1 font-medium">
                      <CheckCircle className="w-3 h-3 shrink-0" />
                      <span className="truncate">{art.verifiedBy}</span>
                    </p>
                  </div>
                </div>

                {/* Footer Controls */}
                <div className="pt-5 mt-6 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{art.publishDate}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={art.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 text-slate-400 hover:text-teal-700 rounded-lg hover:bg-slate-100 transition-colors"
                      title={t.health.readOriginal}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>

                    <button
                      onClick={() => setActiveReadArticle(art)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>{language === 'fr' ? 'Détails certifiés' : 'Verified details'}</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Institutional Health Vigilance Note with WHO & Vidal logos text */}
        <div className="mt-12 p-5 rounded-2xl bg-teal-50/70 border border-teal-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-teal-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-600 text-white font-bold shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-sm text-teal-950">
                Flux Automatisé OMS (Organisation Mondiale de la Santé) & Base VIDAL
              </p>
              <p className="text-teal-800 mt-0.5">
                Notre robot d'ingestion vérifie chaque heure les dernières alertes sanitaires, notices de pharmacovigilance et retraits de lots de médicaments.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveCommentTarget({
              type: 'suggestion',
              id: 'pharmacovigilance-alert',
              title: 'Signalement Médical / Pharmacovigilance',
            })}
            className="whitespace-nowrap px-4 py-2 bg-teal-800 hover:bg-teal-900 text-white font-bold rounded-xl transition-colors shadow-xs self-start sm:self-auto"
          >
            {language === 'fr' ? 'Signaler une alerte' : 'Report an alert'}
          </button>
        </div>

      </div>
    </section>
  );
};
