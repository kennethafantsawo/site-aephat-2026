import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  MessageSquare, 
  Send, 
  ShieldCheck, 
  User, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  CornerDownRight
} from 'lucide-react';

export const CommentsModal: React.FC = () => {
  const { 
    activeCommentsPostId, 
    setActiveCommentsPostId, 
    posts, 
    surveys,
    comments, 
    addComment, 
    currentUser, 
    language, 
    t,
    isAdminMode
  } = useApp();

  const [authorName, setAuthorName] = useState(currentUser?.name || '');
  const [authorEmail, setAuthorEmail] = useState(currentUser?.email || '');
  const [commentText, setCommentText] = useState('');
  const [justSubmitted, setJustSubmitted] = useState(false);

  if (!activeCommentsPostId) return null;

  // Find target item (post or survey)
  const targetPost = posts.find(p => p.id === activeCommentsPostId);
  const targetSurvey = surveys.find(s => s.id === activeCommentsPostId);
  const targetTitle = targetPost ? targetPost.title[language] : (targetSurvey ? targetSurvey.title[language] : 'Publication');

  // Filter comments for this item
  const itemComments = comments.filter(c => 
    c.targetId === activeCommentsPostId && (isAdminMode ? true : c.status !== 'hidden')
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const finalName = currentUser?.name || authorName.trim() || (language === 'fr' ? 'Étudiant / Visiteur' : 'Student / Visitor');
    const finalEmail = currentUser?.email || authorEmail.trim() || 'visiteur@aephat.tg';

    addComment({
      targetType: targetPost ? 'post' : 'survey',
      targetId: activeCommentsPostId,
      targetTitle,
      authorName: finalName,
      authorEmail: finalEmail,
      authorRole: currentUser?.role || 'visitor',
      isVerifiedUser: currentUser?.isVerified || false,
      content: commentText.trim(),
      visibility: 'public',
      status: 'published', // immediately visible as requested!
    });

    setCommentText('');
    setJustSubmitted(true);
    setTimeout(() => setJustSubmitted(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 relative max-h-[92vh] flex flex-col animate-fade-in">
        
        {/* Close button */}
        <button
          onClick={() => setActiveCommentsPostId(null)}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          title={t.posts.close}
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4 pr-8">
          <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{t.commentModal.title}</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 mt-2 font-heading line-clamp-2">
            {targetTitle}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {language === 'fr' 
              ? `${itemComments.length} commentaire(s) publié(s) • Modération continue par le bureau`
              : `${itemComments.length} comment(s) posted • Active board moderation`}
          </p>
        </div>

        {/* Feedback Success */}
        {justSubmitted && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{t.commentModal.successMessage}</span>
          </div>
        )}

        {/* Comments List (Scrollable) */}
        <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 my-2">
          {itemComments.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
              <MessageSquare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-600">
                {language === 'fr' ? 'Aucun commentaire pour le moment.' : 'No comments yet.'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {language === 'fr' ? 'Soyez le premier à réagir ci-dessous !' : 'Be the first to share your thoughts below!'}
              </p>
            </div>
          ) : (
            itemComments.map((comm) => (
              <div 
                key={comm.id}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs flex flex-col gap-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px]">
                      {comm.authorName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900">{comm.authorName}</span>
                        {comm.isVerifiedUser && (
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" title="Membre Vérifié" />
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 capitalize">{comm.authorRole}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400">{comm.createdAt}</span>
                </div>

                <p className="text-slate-700 leading-relaxed pl-8">
                  {comm.content}
                </p>

                {/* Admin Reply if present */}
                {comm.adminReply && (
                  <div className="ml-8 mt-1 p-2.5 rounded-lg bg-emerald-100/60 border border-emerald-200 text-emerald-950 flex items-start gap-2">
                    <CornerDownRight className="w-3.5 h-3.5 text-emerald-700 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-[10px] text-emerald-800">{t.commentModal.replyFromAdmin}</p>
                      <p className="text-[11px] text-emerald-900 mt-0.5">{comm.adminReply}</p>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Comment Input Form */}
        <form onSubmit={handleSubmit} className="mt-3 pt-3 border-t border-slate-200 flex flex-col gap-2.5">
          {!currentUser && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                required
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder={t.commentModal.nameLabel}
                className="text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <input
                type="email"
                required
                value={authorEmail}
                onChange={(e) => setAuthorEmail(e.target.value)}
                placeholder={t.commentModal.emailLabel}
                className="text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          )}

          <div className="relative">
            <textarea
              required
              rows={2}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={t.commentModal.messageLabel}
              className="w-full text-xs p-3 pr-24 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
            />
            <button
              type="submit"
              className="absolute bottom-2.5 right-2.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t.commentModal.submitBtn}</span>
            </button>
          </div>

          <p className="text-[10px] text-slate-400 text-center">
            {language === 'fr'
              ? 'Visible immédiatement • Les messages font l’objet d’une modération conforme à la charte de l’AEPHAT.'
              : 'Immediately published • Comments are reviewed according to AEPHAT community guidelines.'}
          </p>
        </form>

      </div>
    </div>
  );
};
