import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Lock, 
  Send, 
  ShieldCheck, 
  CheckCircle2, 
  MessageSquareLock,
  Mail
} from 'lucide-react';

export const PrivateCommentModal: React.FC = () => {
  const { 
    activeCommentTarget, 
    setActiveCommentTarget, 
    addPrivateComment, 
    currentUser, 
    language, 
    t 
  } = useApp();

  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [content, setContent] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!activeCommentTarget) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !content.trim()) return;

    addPrivateComment({
      targetType: activeCommentTarget.type,
      targetId: activeCommentTarget.id,
      targetTitle: activeCommentTarget.title,
      authorName: name.trim() || 'Visiteur anonyme',
      authorEmail: email.trim(),
      authorRole: currentUser?.role || 'visitor',
      isVerifiedUser: currentUser?.isVerified || false,
      content: content.trim(),
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setContent('');
      setActiveCommentTarget(null);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
        
        {/* Close */}
        <button
          onClick={() => setActiveCommentTarget(null)}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
            <Lock className="w-3.5 h-3.5" />
            <span>Message Privé Confidentiel</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-2 font-heading">
            {t.commentModal.title}
          </h3>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            Concerne : <span className="text-slate-900 font-bold">« {activeCommentTarget.title} »</span>
          </p>
        </div>

        {/* Security Notice */}
        <div className="mb-5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-start gap-2">
          <MessageSquareLock className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
          <span>{t.commentModal.subtitle}</span>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <p className="text-sm font-bold text-slate-900">
              {t.commentModal.successMessage}
            </p>
            <p className="text-xs text-slate-500">
              {language === 'fr' 
                ? 'Les administrateurs pourront vous répondre directement à votre adresse e-mail.' 
                : 'The executive board will be able to follow up directly at your email address.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.commentModal.nameLabel}
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Kodjo Mensah"
                className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.commentModal.emailLabel} *
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre.email@exemple.com"
                  className="w-full text-xs p-3 pr-10 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.commentModal.messageLabel} *
              </label>
              <textarea
                required
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Partagez votre avis, vos questions ou vos retours sur ce sujet..."
                className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t.commentModal.submitBtn}</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
