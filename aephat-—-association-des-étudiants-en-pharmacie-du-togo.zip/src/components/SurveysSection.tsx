import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Survey } from '../types';
import { 
  BarChart3, 
  ExternalLink, 
  Lock, 
  CheckCircle2, 
  Users, 
  Calendar, 
  MessageSquare, 
  ShieldCheck, 
  FileSpreadsheet,
  Vote,
  Sparkles,
  Info
} from 'lucide-react';

export const SurveysSection: React.FC = () => {
  const { 
    surveys, 
    currentUser, 
    language, 
    t, 
    setActiveStatsSurvey, 
    setActiveCommentTarget,
    setIsAuthModalOpen 
  } = useApp();

  const [activeFormModal, setActiveFormModal] = useState<Survey | null>(null);

  const canParticipate = (survey: Survey): { allowed: boolean; reason?: string } => {
    if (survey.restriction === 'all_with_email') {
      return { allowed: true };
    }
    // Verified only
    if (!currentUser) {
      return { 
        allowed: false, 
        reason: language === 'fr' 
          ? 'Connexion requise : Ce sondage est réservé aux étudiants et docteurs en pharmacie vérifiés.' 
          : 'Sign-in required: This survey is reserved for verified pharmacy students and doctors.' 
      };
    }
    if (!currentUser.isVerified || (currentUser.role !== 'student' && currentUser.role !== 'doctor')) {
      return { 
        allowed: false, 
        reason: language === 'fr' 
          ? 'Validation requise : Votre profil est en attente de vérification par le bureau AEPHAT.' 
          : 'Validation required: Your account is pending verification by the AEPHAT board.' 
      };
    }
    return { allowed: true };
  };

  return (
    <section id="surveys" className="py-20 bg-slate-50 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-800 bg-amber-100/90 px-3 py-1 rounded-full border border-amber-200">
            <Vote className="w-3.5 h-3.5 text-amber-700" />
            {t.surveys.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-heading tracking-tight">
            {t.surveys.title}
          </h2>
          <p className="text-base text-slate-600 mt-2 leading-relaxed">
            {t.surveys.subtitle}
          </p>
        </div>

        {/* Survey Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {surveys.map((survey) => {
            const access = canParticipate(survey);

            return (
              <div
                key={survey.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Status and Rule badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                    {survey.restriction === 'verified_only' ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{t.surveys.ruleVerifiedOnly}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg bg-blue-100 text-blue-800 border border-blue-200">
                        <Users className="w-3.5 h-3.5 text-blue-600" />
                        <span>{t.surveys.ruleAllWithEmail}</span>
                      </span>
                    )}

                    <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Date limite : {survey.deadline}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-slate-900 leading-snug">
                    {survey.title[language]}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-600 mt-3 leading-relaxed">
                    {survey.description[language]}
                  </p>

                  {/* Live Stats Preview Box */}
                  <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200/90">
                    <div className="flex items-center justify-between text-xs mb-3">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <BarChart3 className="w-4 h-4 text-emerald-600" />
                        {language === 'fr' ? 'Tendance actuelle des votes' : 'Current Voting Breakdown'}
                      </span>
                      <span className="font-semibold text-slate-500">
                        {survey.responsesCount} {t.surveys.statsTotalVotes}
                      </span>
                    </div>

                    {/* Progress bars preview */}
                    <div className="space-y-2.5">
                      {survey.resultsSummary.options.slice(0, 2).map((opt) => (
                        <div key={opt.id} className="space-y-1">
                          <div className="flex justify-between text-xs font-medium text-slate-700">
                            <span className="truncate max-w-[260px]">{opt.label[language]}</span>
                            <span className="font-bold text-slate-900">{opt.percent}%</span>
                          </div>
                          <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-500"
                              style={{ width: `${opt.percent}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    <p className="text-[11px] text-slate-500 mt-3 flex items-center gap-1 italic">
                      <Info className="w-3 h-3 text-slate-400" />
                      {language === 'fr' ? 'Synchronisé avec Google Sheets de l’AEPHAT' : 'Synced with AEPHAT Google Sheets'}
                    </p>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="pt-6 mt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  
                  {/* Participate button with access check */}
                  {access.allowed ? (
                    <button
                      onClick={() => setActiveFormModal(survey)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-xs hover:shadow transition-all"
                    >
                      <Vote className="w-4 h-4" />
                      <span>{t.surveys.btnParticipate}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setIsAuthModalOpen(true)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold transition-all border border-slate-300"
                      title={access.reason}
                    >
                      <Lock className="w-4 h-4 text-amber-600" />
                      <span>{language === 'fr' ? 'Se connecter pour voter' : 'Sign in to vote'}</span>
                    </button>
                  )}

                  {/* 1-Click Stats View Button */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveStatsSurvey(survey)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs font-bold transition-colors border border-slate-200"
                      title="Afficher les statistiques détaillées"
                    >
                      <BarChart3 className="w-4 h-4 text-emerald-600" />
                      <span>{t.surveys.btnViewStats}</span>
                    </button>

                    {/* Private comment/feedback on survey */}
                    <button
                      onClick={() => setActiveCommentTarget({
                        type: 'survey',
                        id: survey.id,
                        title: survey.title[language],
                      })}
                      className="p-2 text-slate-400 hover:text-slate-800 rounded-xl hover:bg-slate-100 transition-colors"
                      title={t.surveys.btnGiveFeedback}
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Google Form Simulation Modal */}
      {activeFormModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
                  Google Forms • AEPHAT Officiel
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-2">
                  {activeFormModal.title[language]}
                </h3>
              </div>
              <button
                onClick={() => setActiveFormModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700 text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-6">
              {language === 'fr'
                ? 'Les réponses sont collectées de manière sécurisée et anonymisée. L’accès est vérifié par le bureau exécutif.'
                : 'Responses are securely collected and anonymized. Access is verified by the executive board.'}
            </p>

            {/* Interactive Survey Options */}
            <div className="space-y-4 mb-6">
              <label className="block text-sm font-bold text-slate-800">
                {language === 'fr' ? 'Choisissez votre proposition prioritaire :' : 'Select your priority option:'}
              </label>
              {activeFormModal.resultsSummary.options.map((opt, idx) => (
                <label 
                  key={opt.id}
                  className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-emerald-50/50 hover:border-emerald-300 cursor-pointer transition-all"
                >
                  <input type="radio" name="survey-vote" className="w-4 h-4 text-emerald-600 focus:ring-emerald-500" defaultChecked={idx === 0} />
                  <span className="text-sm font-medium text-slate-800">{opt.label[language]}</span>
                </label>
              ))}

              <div className="space-y-1.5 pt-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {language === 'fr' ? 'Remarque ou commentaire pour les administrateurs (privé) :' : 'Private feedback for administrators:'}
                </label>
                <textarea
                  rows={2}
                  placeholder={language === 'fr' ? 'Votre remarque éventuelle...' : 'Optional comment...'}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <a
                href={activeFormModal.googleFormUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-medium text-slate-500 hover:text-emerald-700 flex items-center gap-1"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>{language === 'fr' ? 'Ouvrir le formulaire Google Forms externe' : 'Open external Google Form'}</span>
              </a>

              <button
                onClick={() => {
                  alert(language === 'fr' ? 'Merci ! Votre vote a été enregistré avec succès.' : 'Thank you! Your response has been recorded.');
                  setActiveFormModal(null);
                }}
                className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-bold rounded-xl transition-colors"
              >
                {language === 'fr' ? 'Soumettre mon vote' : 'Submit My Vote'}
              </button>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
