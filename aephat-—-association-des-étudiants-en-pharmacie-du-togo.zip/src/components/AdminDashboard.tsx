import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  AdminRole, 
  Post, 
  HealthArticle, 
  Survey, 
  User, 
  CommentItem, 
  BoardMember,
  PostCategory,
  PostStatus,
  HealthSource,
  HealthCategory,
  UserRole
} from '../types';
import { 
  ShieldCheck, 
  FileText, 
  HeartHandshake, 
  Vote, 
  MessageSquare, 
  Users, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  X, 
  ExternalLink, 
  ArrowLeft,
  Sparkles,
  BarChart3,
  Calendar,
  Clock,
  Send,
  Eye,
  EyeOff,
  RotateCw,
  Search,
  CheckCircle2,
  Mail,
  Phone,
  MessageCircle,
  Database,
  Globe2,
  Lock
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    language, 
    t, 
    setIsAdminMode, 
    adminRole, 
    setAdminRole,
    posts,
    addPost,
    editPost,
    deletePost,
    publishPostNow,
    boardMembers,
    addBoardMember,
    editBoardMember,
    deleteBoardMember,
    surveys,
    addSurvey,
    editSurvey,
    deleteSurvey,
    toggleSurveyActive,
    healthArticles,
    addHealthArticle,
    deleteHealthArticle,
    lastHealthSyncTime,
    isSyncingHealth,
    syncHealthWithOmsAndVidal,
    comments,
    updateCommentStatus,
    deleteComment,
    members,
    addMember,
    editMember,
    approveMember,
    rejectMember,
    deleteMember,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'posts' | 'board' | 'surveys' | 'comments' | 'members' | 'health'>('posts');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  // --- POSTS STATE & HANDLERS ---
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [postFilterStatus, setPostFilterStatus] = useState<'all' | PostStatus>('all');
  const [postForm, setPostForm] = useState({
    titleFr: '',
    titleEn: '',
    excerptFr: '',
    excerptEn: '',
    contentFr: '',
    contentEn: '',
    category: 'evenement' as PostCategory,
    author: 'Kofi Mawuli Mensah',
    authorRole: 'Président AEPHAT',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=80',
    tags: 'Événement, Pharmacie, FSS',
    isTestPost: false,
    status: 'published' as PostStatus,
    scheduledDate: '',
  });

  const handleOpenNewPost = () => {
    setEditingPostId(null);
    setPostForm({
      titleFr: '',
      titleEn: '',
      excerptFr: '',
      excerptEn: '',
      contentFr: '',
      contentEn: '',
      category: 'evenement',
      author: 'Kofi Mawuli Mensah',
      authorRole: 'Président AEPHAT',
      imageUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1200&q=80',
      tags: 'Actualité, AEPHAT, Santé',
      isTestPost: false,
      status: 'published',
      scheduledDate: '',
    });
    setIsPostModalOpen(true);
  };

  const handleEditPost = (post: Post) => {
    setEditingPostId(post.id);
    setPostForm({
      titleFr: post.title.fr,
      titleEn: post.title.en,
      excerptFr: post.excerpt.fr,
      excerptEn: post.excerpt.en,
      contentFr: post.content.fr,
      contentEn: post.content.en,
      category: post.category,
      author: post.author,
      authorRole: post.authorRole,
      imageUrl: post.imageUrl || '',
      tags: post.tags.join(', '),
      isTestPost: !!post.isTestPost,
      status: post.status || 'published',
      scheduledDate: post.scheduledDate || '',
    });
    setIsPostModalOpen(true);
  };

  const handleSavePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postForm.titleFr.trim()) return;

    const tagArray = postForm.tags.split(',').map(t => t.trim()).filter(Boolean);
    const now = new Date();
    const formattedDate = now.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });

    if (editingPostId) {
      editPost(editingPostId, {
        title: { fr: postForm.titleFr, en: postForm.titleEn || postForm.titleFr },
        excerpt: { fr: postForm.excerptFr, en: postForm.excerptEn || postForm.excerptFr },
        content: { fr: postForm.contentFr, en: postForm.contentEn || postForm.contentFr },
        category: postForm.category,
        author: postForm.author,
        authorRole: postForm.authorRole,
        imageUrl: postForm.imageUrl,
        isTestPost: postForm.isTestPost,
        tags: tagArray,
        status: postForm.status,
        scheduledDate: postForm.status === 'scheduled' ? postForm.scheduledDate : undefined,
      });
      showToast('Publication modifiée avec succès !');
    } else {
      addPost({
        title: { fr: postForm.titleFr, en: postForm.titleEn || postForm.titleFr },
        excerpt: { fr: postForm.excerptFr, en: postForm.excerptEn || postForm.excerptFr },
        content: { fr: postForm.contentFr, en: postForm.contentEn || postForm.contentFr },
        category: postForm.category,
        author: postForm.author,
        authorRole: postForm.authorRole,
        date: formattedDate,
        imageUrl: postForm.imageUrl,
        isTestPost: postForm.isTestPost,
        allowComments: true,
        tags: tagArray,
        status: postForm.status,
        scheduledDate: postForm.status === 'scheduled' ? postForm.scheduledDate : undefined,
      });
      showToast('Nouvelle publication enregistrée avec succès !');
    }

    setIsPostModalOpen(false);
    setEditingPostId(null);
  };

  // --- BOARD EXECUTIVE STATE & HANDLERS ---
  const [isBoardModalOpen, setIsBoardModalOpen] = useState(false);
  const [editingBoardId, setEditingBoardId] = useState<string | null>(null);
  const [boardForm, setBoardForm] = useState({
    name: '',
    roleFr: '',
    roleEn: '',
    category: 'executif' as BoardMember['category'],
    level: '5ème Année Pharmacie',
    email: '',
    phone: '',
    whatsapp: '',
    photoUrl: '',
    bioFr: '',
    bioEn: '',
  });

  const handleOpenNewBoard = () => {
    setEditingBoardId(null);
    setBoardForm({
      name: '',
      roleFr: '',
      roleEn: '',
      category: 'executif',
      level: '4ème Année Pharmacie',
      email: '',
      phone: '+228 ',
      whatsapp: '228',
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      bioFr: '',
      bioEn: '',
    });
    setIsBoardModalOpen(true);
  };

  const handleEditBoard = (member: BoardMember) => {
    setEditingBoardId(member.id);
    setBoardForm({
      name: member.name,
      roleFr: member.role.fr,
      roleEn: member.role.en,
      category: member.category,
      level: member.level,
      email: member.email,
      phone: member.phone,
      whatsapp: member.whatsapp,
      photoUrl: member.photoUrl,
      bioFr: member.bio.fr,
      bioEn: member.bio.en,
    });
    setIsBoardModalOpen(true);
  };

  const handleSaveBoard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!boardForm.name.trim() || !boardForm.roleFr.trim()) return;

    if (editingBoardId) {
      editBoardMember(editingBoardId, {
        name: boardForm.name,
        role: { fr: boardForm.roleFr, en: boardForm.roleEn || boardForm.roleFr },
        category: boardForm.category,
        level: boardForm.level,
        email: boardForm.email,
        phone: boardForm.phone,
        whatsapp: boardForm.whatsapp,
        photoUrl: boardForm.photoUrl,
        bio: { fr: boardForm.bioFr, en: boardForm.bioEn || boardForm.bioFr },
      });
      showToast('Membre du bureau mis à jour !');
    } else {
      addBoardMember({
        name: boardForm.name,
        role: { fr: boardForm.roleFr, en: boardForm.roleEn || boardForm.roleFr },
        category: boardForm.category,
        level: boardForm.level,
        email: boardForm.email,
        phone: boardForm.phone,
        whatsapp: boardForm.whatsapp,
        photoUrl: boardForm.photoUrl,
        bio: { fr: boardForm.bioFr, en: boardForm.bioEn || boardForm.bioFr },
        order: boardMembers.length + 1,
      });
      showToast('Nouveau poste ajouté au bureau !');
    }

    setIsBoardModalOpen(false);
    setEditingBoardId(null);
  };

  // --- SURVEYS STATE & HANDLERS ---
  const [isSurveyModalOpen, setIsSurveyModalOpen] = useState(false);
  const [editingSurveyId, setEditingSurveyId] = useState<string | null>(null);
  const [surveyForm, setSurveyForm] = useState({
    titleFr: '',
    titleEn: '',
    descriptionFr: '',
    descriptionEn: '',
    googleFormUrl: '',
    resultsAccessEmail: 'commission.elections@aephat.tg',
    restriction: 'verified_only' as 'all_with_email' | 'verified_only',
    deadline: '30 Avril 2026',
    opt1Fr: 'Option favorable',
    opt1En: 'Favorable option',
    opt2Fr: 'Option défavorable',
    opt2En: 'Unfavorable option',
  });

  const handleOpenNewSurvey = () => {
    setEditingSurveyId(null);
    setSurveyForm({
      titleFr: '',
      titleEn: '',
      descriptionFr: '',
      descriptionEn: '',
      googleFormUrl: 'https://docs.google.com/forms/d/e/1FAIpQLSc-NOUVEAU-SONDAGE-AEPHAT/viewform',
      resultsAccessEmail: 'sondages@aephat.tg',
      restriction: 'all_with_email',
      deadline: '15 Mai 2026',
      opt1Fr: 'Oui, tout à fait',
      opt1En: 'Yes, absolutely',
      opt2Fr: 'Non, pas prioritaire',
      opt2En: 'No, not a priority',
    });
    setIsSurveyModalOpen(true);
  };

  const handleSaveSurvey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!surveyForm.titleFr.trim()) return;

    if (editingSurveyId) {
      editSurvey(editingSurveyId, {
        title: { fr: surveyForm.titleFr, en: surveyForm.titleEn || surveyForm.titleFr },
        description: { fr: surveyForm.descriptionFr, en: surveyForm.descriptionEn || surveyForm.descriptionFr },
        googleFormUrl: surveyForm.googleFormUrl.trim() || 'https://forms.google.com',
        resultsAccessEmail: surveyForm.resultsAccessEmail.trim() || 'sondages@aephat.tg',
        restriction: surveyForm.restriction,
        deadline: surveyForm.deadline,
      });
      showToast('Sondage mis à jour avec succès !');
    } else {
      addSurvey({
        title: { fr: surveyForm.titleFr, en: surveyForm.titleEn || surveyForm.titleFr },
        description: { fr: surveyForm.descriptionFr, en: surveyForm.descriptionEn || surveyForm.descriptionFr },
        googleFormUrl: surveyForm.googleFormUrl.trim() || 'https://forms.google.com',
        googleFormEmbedUrl: `${surveyForm.googleFormUrl.trim()}?embedded=true`,
        resultsAccessEmail: surveyForm.resultsAccessEmail.trim() || 'commission.sondages@aephat.tg',
        restriction: surveyForm.restriction,
        deadline: surveyForm.deadline,
        isActive: true,
        resultsSummary: {
          total: 0,
          options: [
            { id: 'opt-1', label: { fr: surveyForm.opt1Fr, en: surveyForm.opt1En || surveyForm.opt1Fr }, votesCount: 0, percent: 50 },
            { id: 'opt-2', label: { fr: surveyForm.opt2Fr, en: surveyForm.opt2En || surveyForm.opt2Fr }, votesCount: 0, percent: 50 },
          ],
        },
      });
      showToast('Nouveau sondage créé et visible dans les actualités !');
    }

    setIsSurveyModalOpen(false);
    setEditingSurveyId(null);
  };

  // --- HEALTH & IMPORT STATE & HANDLERS ---
  const [isHealthModalOpen, setIsHealthModalOpen] = useState(false);
  const [healthForm, setHealthForm] = useState({
    titleFr: '',
    titleEn: '',
    summaryFr: '',
    summaryEn: '',
    contentFr: '',
    contentEn: '',
    source: 'Base VIDAL France / ANSM',
    sourceType: 'VIDAL' as HealthSource,
    sourceUrl: 'https://www.vidal.fr',
    verifiedBy: 'Commission Scientifique & Galénique AEPHAT',
    category: 'pharmacovigilance' as HealthCategory,
    readTimeMinutes: 3,
  });

  const handleImportPreset = (presetType: 'vidal_alert' | 'who_bulletin') => {
    if (presetType === 'vidal_alert') {
      setHealthForm({
        titleFr: 'VIDAL Alerte : Vigilance renforcée sur l’association AINS et anticoagulants oraux directs (AOD)',
        titleEn: 'VIDAL Alert: Heightened precautions on co-prescribing NSAIDs and direct oral anticoagulants',
        summaryFr: 'Le VIDAL et l’ANSM rappellent le risque d’hémorragies digestives majeures en cas d’automédication par ibuprofène chez les patients sous AOD.',
        summaryEn: 'VIDAL drug safety board warns of major gastrointestinal hemorrhage risks with OTC ibuprofen in patients on DOACs.',
        contentFr: 'La prise concomitante d’anti-inflammatoires non stéroïdiens (ibuprofène, kétoprofène) avec les anticoagulants oraux directs (apixaban, rivaroxaban) majore considérablement le risque hémorragique. Les officinaux togolais doivent systématiquement interroger les patients demandeurs d’antalgiques sur la prise d’anticoagulants.',
        contentEn: 'Concomitant administration of NSAIDs with direct oral anticoagulants increases major bleeding risks.',
        source: 'VIDAL France Sécurité Médicamenteuse',
        sourceType: 'VIDAL',
        sourceUrl: 'https://www.vidal.fr',
        verifiedBy: 'Dr. Komla Agbessi, Pharmacologue hospitalier FSS Lomé',
        category: 'pharmacovigilance',
        readTimeMinutes: 3,
      });
    } else {
      setHealthForm({
        titleFr: 'OMS Afrique & Togo : Recommandations pour la saison de transmission palustre 2026',
        titleEn: 'WHO Africa & Togo: Policy guidance for 2026 malaria high-transmission season',
        summaryFr: 'L’OMS préconise l’extension de la chimioprévention du paludisme saisonnier (CPS) et le bon usage des tests de diagnostic rapide (TDR).',
        summaryEn: 'WHO recommends expansion of seasonal malaria chemoprevention (SMC) and adherence to rapid diagnostic tests (RDTs).',
        contentFr: 'Dans son dernier bulletin régional pour l’Afrique de l’Ouest, l’Organisation Mondiale de la Santé insiste sur la confirmation biologique par TDR avant tout traitement par CTA, afin d’éviter l’émergence de résistances.',
        contentEn: 'In its regional West Africa bulletin, WHO emphasizes biological parasite confirmation via RDT prior to ACT dispensation.',
        source: 'Organisation Mondiale de la Santé (OMS)',
        sourceType: 'OMS',
        sourceUrl: 'https://www.who.int/fr',
        verifiedBy: 'Comité de Veille Épidémiologique AEPHAT',
        category: 'prevention',
        readTimeMinutes: 4,
      });
    }
  };

  const handleSaveHealthArticle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!healthForm.titleFr.trim()) return;

    addHealthArticle({
      title: { fr: healthForm.titleFr, en: healthForm.titleEn || healthForm.titleFr },
      summary: { fr: healthForm.summaryFr, en: healthForm.summaryEn || healthForm.summaryFr },
      content: { fr: healthForm.contentFr, en: healthForm.contentEn || healthForm.contentFr },
      source: healthForm.source,
      sourceType: healthForm.sourceType,
      sourceUrl: healthForm.sourceUrl,
      verifiedBy: healthForm.verifiedBy,
      publishDate: 'Aujourd’hui (Importé)',
      category: healthForm.category,
      readTimeMinutes: Number(healthForm.readTimeMinutes) || 3,
    });

    showToast('Article officiel importé avec succès !');
    setIsHealthModalOpen(false);
  };

  // --- MEMBERS MANAGEMENT STATE & HANDLERS ---
  const [memberSearch, setMemberSearch] = useState('');
  const [memberFilterStatus, setMemberFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [editingMemberId, setEditingMemberId] = useState<string | null>(null);
  const [memberForm, setMemberForm] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'student' as UserRole,
    facultyId: '',
    academicYear: '4ème Année Pharmacie',
    status: 'approved' as User['status'],
    isVerified: true,
  });

  const handleOpenNewMember = () => {
    setEditingMemberId(null);
    setMemberForm({
      name: '',
      email: '',
      phone: '+228 ',
      role: 'student',
      facultyId: 'FSS-PHARM-2024-',
      academicYear: '3ème Année Pharmacie',
      status: 'approved',
      isVerified: true,
    });
    setIsMemberModalOpen(true);
  };

  const handleEditMember = (m: User) => {
    setEditingMemberId(m.id);
    setMemberForm({
      name: m.name,
      email: m.email,
      phone: m.phone || '',
      role: m.role,
      facultyId: m.facultyId || '',
      academicYear: m.academicYear || '',
      status: m.status,
      isVerified: m.isVerified,
    });
    setIsMemberModalOpen(true);
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberForm.name.trim() || !memberForm.email.trim()) return;

    if (editingMemberId) {
      editMember(editingMemberId, {
        name: memberForm.name,
        email: memberForm.email,
        phone: memberForm.phone,
        role: memberForm.role,
        facultyId: memberForm.facultyId,
        academicYear: memberForm.academicYear,
        status: memberForm.status,
        isVerified: memberForm.status === 'approved',
      });
      showToast('Informations du membre mises à jour !');
    } else {
      addMember({
        name: memberForm.name,
        email: memberForm.email,
        phone: memberForm.phone,
        role: memberForm.role,
        facultyId: memberForm.facultyId,
        academicYear: memberForm.academicYear,
        status: memberForm.status,
        isVerified: memberForm.status === 'approved',
      });
      showToast('Nouveau membre ajouté avec succès !');
    }

    setIsMemberModalOpen(false);
    setEditingMemberId(null);
  };

  const filteredMembers = members.filter(m => {
    const matchesSearch = 
      m.name.toLowerCase().includes(memberSearch.toLowerCase()) ||
      m.email.toLowerCase().includes(memberSearch.toLowerCase()) ||
      (m.facultyId && m.facultyId.toLowerCase().includes(memberSearch.toLowerCase()));
    
    if (!matchesSearch) return false;
    if (memberFilterStatus === 'all') return true;
    return m.status === memberFilterStatus;
  });

  // --- COMMENTS MANAGEMENT STATE & HANDLERS ---
  const [commentReplyId, setCommentReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleSendReply = (commentId: string) => {
    if (!replyText.trim()) return;
    updateCommentStatus(commentId, 'published', replyText.trim());
    setReplyText('');
    setCommentReplyId(null);
    showToast('Réponse officielle publiée avec succès !');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 pb-20">
      
      {/* Admin Top Navigation */}
      <header className="sticky top-0 z-30 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAdminMode(false)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t.admin.exitAdmin}</span>
            </button>
            <div className="flex items-center gap-2">
              <span className="text-base sm:text-lg font-black tracking-tight text-white font-heading">
                admin.aephat.tg
              </span>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">
                Supervision
              </span>
            </div>
          </div>

          {/* Admin Role Selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 hidden sm:inline">{t.admin.activeRoleBadge}</span>
            <select
              value={adminRole}
              onChange={(e) => setAdminRole(e.target.value as AdminRole)}
              className="bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 font-semibold"
            >
              <option value="president">{t.admin.rolePresident}</option>
              <option value="vice_president">{t.admin.roleVicePresident}</option>
              <option value="comms_director">{t.admin.roleComms}</option>
            </select>
          </div>
        </div>
      </header>

      {/* Success Toast */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-8 pt-8">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-4 mb-8">
          <button
            onClick={() => setActiveTab('posts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'posts'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{t.admin.tabPosts} ({posts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('board')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'board'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{t.admin.tabBoard} ({boardMembers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('surveys')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'surveys'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Vote className="w-4 h-4" />
            <span>{t.admin.tabSurveys} ({surveys.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('comments')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'comments'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>{t.admin.tabComments} ({comments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('members')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'members'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{t.admin.tabMembers} ({members.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('health')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'health'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>{t.admin.tabHealth} ({healthArticles.length})</span>
          </button>
        </div>

        {/* TAB 1: POSTS & SCHEDULED MANAGEMENT */}
        {activeTab === 'posts' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Gestion des Publications & Planning de Diffusion
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Créez des articles, modifiez le contenu existant ou programmez une publication automatique.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleOpenNewPost}
                  className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.admin.btnNewPost}</span>
                </button>
              </div>
            </div>

            {/* Filter pills: Toutes / Publiées / Programmées / Brouillons */}
            <div className="flex items-center gap-2 text-xs">
              {(['all', 'published', 'scheduled', 'draft'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setPostFilterStatus(st)}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                    postFilterStatus === st
                      ? 'bg-slate-700 text-white border border-slate-600'
                      : 'bg-slate-800/60 text-slate-400 hover:text-white'
                  }`}
                >
                  {st === 'all' ? 'Toutes' : st === 'published' ? 'Publiées' : st === 'scheduled' ? 'Programmées' : 'Brouillons'}
                </button>
              ))}
            </div>

            {/* Posts Table */}
            <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Titre & Catégorie</th>
                      <th className="p-4">Auteur</th>
                      <th className="p-4">Statut & Date</th>
                      <th className="p-4">Interactions</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {posts
                      .filter(p => postFilterStatus === 'all' ? true : p.status === postFilterStatus)
                      .map((post) => {
                        const postComments = comments.filter(c => c.targetId === post.id);

                        return (
                          <tr key={post.id} className="hover:bg-slate-900/50 transition-colors">
                            <td className="p-4">
                              <p className="font-bold text-white text-sm line-clamp-1">{post.title.fr}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-slate-800 text-emerald-400 border border-slate-700">
                                  {post.category}
                                </span>
                                {post.isTestPost && (
                                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-900/60 text-blue-300">
                                    Test Post
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-4 text-slate-300 font-medium">
                              {post.author}
                            </td>
                            <td className="p-4">
                              <div className="flex flex-col gap-1">
                                {post.status === 'scheduled' ? (
                                  <span className="inline-flex items-center gap-1 text-amber-400 font-bold text-[11px]">
                                    <Clock className="w-3.5 h-3.5" />
                                    <span>Programmé : {post.scheduledDate ? new Date(post.scheduledDate).toLocaleDateString() : 'Bientôt'}</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-emerald-400 font-bold text-[11px]">
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>Publié ({post.date})</span>
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-4 text-slate-400">
                              <span>❤️ {post.likes}</span> • <span>💬 {postComments.length} coms</span>
                            </td>
                            <td className="p-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                {post.status === 'scheduled' && (
                                  <button
                                    onClick={() => {
                                      publishPostNow(post.id);
                                      showToast('Publication publiée immédiatement !');
                                    }}
                                    className="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors"
                                    title="Publier immédiatement"
                                  >
                                    Publier
                                  </button>
                                )}

                                <button
                                  onClick={() => handleEditPost(post)}
                                  className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                                  title="Modifier la publication"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>

                                <button
                                  onClick={() => {
                                    if (confirm(t.admin.deleteConfirm)) {
                                      deletePost(post.id);
                                      showToast('Publication supprimée.');
                                    }
                                  }}
                                  className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                                  title="Supprimer la publication"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BOARD EXECUTIVE (LE BUREAU) */}
        {activeTab === 'board' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Gestion du Bureau Exécutif & Attributions
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Ajoutez de nouveaux postes, modifiez les membres, attribuez les coordonnées officielles (téléphone, WhatsApp, email) et photos.
                </p>
              </div>

              <button
                onClick={handleOpenNewBoard}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-sm transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{t.admin.btnNewBoardMember}</span>
              </button>
            </div>

            {/* Board Members Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {boardMembers.map((member) => (
                <div
                  key={member.id}
                  className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center gap-3.5 mb-3">
                      <img
                        src={member.photoUrl}
                        alt={member.name}
                        className="w-14 h-14 rounded-xl object-cover border border-slate-700 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h4 className="font-bold text-white text-sm">{member.name}</h4>
                        <p className="text-xs text-amber-400 font-semibold">{member.role.fr}</p>
                        <p className="text-[11px] text-slate-400">{member.level}</p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-3 mb-4">
                      {member.bio.fr}
                    </p>

                    {/* Contacts info */}
                    <div className="space-y-1.5 text-xs text-slate-400 border-t border-slate-800/80 pt-3">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{member.phone || 'Non renseigné'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span>WhatsApp : {member.whatsapp || 'Non renseigné'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="truncate">{member.email}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                    <button
                      onClick={() => handleEditBoard(member)}
                      className="px-3 py-1 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Modifier</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer ${member.name} du bureau ?`)) {
                          deleteBoardMember(member.id);
                          showToast('Membre retiré du bureau.');
                        }
                      }}
                      className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-slate-800 transition-colors"
                      title="Supprimer du bureau"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: SURVEYS & GOOGLE FORMS */}
        {activeTab === 'surveys' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Sondages d’Opinion & Intégration Google Forms
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Les sondages apparaissent directement dans le fil d’actualité. L’email gestionnaire est lié pour consulter les réponses Google Forms.
                </p>
              </div>

              <button
                onClick={handleOpenNewSurvey}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-sm transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{t.admin.btnNewSurvey}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {surveys.map((survey) => (
                <div
                  key={survey.id}
                  className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        survey.isActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {survey.isActive ? 'Actif dans le fil' : 'Archivé'}
                      </span>
                      <span className="text-xs text-slate-400">Échéance : {survey.deadline}</span>
                    </div>

                    <h4 className="font-bold text-white text-base mt-1">{survey.title.fr}</h4>
                    <p className="text-xs text-slate-300 mt-2 leading-relaxed">{survey.description.fr}</p>

                    {/* Associated Results Manager Email (Requested Feature 4.2.1) */}
                    <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Email gestionnaire des réponses Google Forms :
                      </p>
                      <div className="flex items-center gap-2 text-amber-400 font-semibold">
                        <Mail className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{survey.resultsAccessEmail}</span>
                      </div>
                    </div>

                    <div className="mt-3 text-xs text-slate-400">
                      <span>Total réponses : <strong className="text-white">{survey.responsesCount}</strong></span> • 
                      <span className="ml-2">Accès : {survey.restriction === 'verified_only' ? 'Vérifié uniquement' : 'Tous avec email'}</span>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                    <a
                      href={survey.googleFormUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 text-xs font-bold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Formulaire</span>
                    </a>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleSurveyActive(survey.id)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                          survey.isActive 
                            ? 'bg-amber-950/60 text-amber-300 hover:bg-amber-900/60' 
                            : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/60'
                        }`}
                      >
                        {survey.isActive ? 'Désactiver' : 'Activer'}
                      </button>

                      <button
                        onClick={() => {
                          if (confirm(t.admin.deleteConfirm)) {
                            deleteSurvey(survey.id);
                            showToast('Sondage supprimé.');
                          }
                        }}
                        className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-slate-800 transition-colors"
                        title="Supprimer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: COMMENTS MODERATION */}
        {activeTab === 'comments' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Modération des Commentaires & Retours
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Les commentaires sont visibles dès leur publication par les utilisateurs. Vous pouvez masquer, valider, répondre officiellement ou supprimer.
                </p>
              </div>
            </div>

            <div className="space-y-3.5">
              {comments.map((comm) => (
                <div
                  key={comm.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    comm.status === 'hidden'
                      ? 'bg-rose-950/20 border-rose-900/50'
                      : 'bg-slate-950 border-slate-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{comm.authorName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded uppercase font-bold bg-slate-800 text-slate-300">
                        {comm.authorRole}
                      </span>
                      {comm.status === 'hidden' && (
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-rose-900/60 text-rose-300">
                          Masqué du public
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-slate-500">{comm.createdAt}</span>
                  </div>

                  <p className="text-xs text-amber-400 font-semibold mb-1">
                    Cible : {comm.targetTitle} ({comm.targetType})
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                    "{comm.content}"
                  </p>

                  {/* Official admin reply if exists */}
                  {comm.adminReply && (
                    <div className="mt-2.5 p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-200">
                      <strong className="text-emerald-400 font-bold">Réponse officielle du bureau :</strong> {comm.adminReply}
                    </div>
                  )}

                  {/* Reply Input Form if triggered */}
                  {commentReplyId === comm.id && (
                    <div className="mt-3 p-3 bg-slate-900 rounded-xl border border-slate-700 flex flex-col gap-2">
                      <textarea
                        rows={2}
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Rédigez la réponse officielle du bureau AEPHAT..."
                        className="w-full text-xs p-2.5 bg-slate-800 border border-slate-600 rounded-lg text-white focus:outline-none"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setCommentReplyId(null)}
                          className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => handleSendReply(comm.id)}
                          className="px-3 py-1 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg"
                        >
                          Publier la réponse
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Action Controls */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500 truncate">Email auteur : {comm.authorEmail}</span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setCommentReplyId(comm.id)}
                        className="px-2.5 py-1 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        Répondre
                      </button>

                      <button
                        onClick={() => {
                          const nextStatus = comm.status === 'hidden' ? 'published' : 'hidden';
                          updateCommentStatus(comm.id, nextStatus);
                          showToast(nextStatus === 'hidden' ? 'Commentaire masqué du public.' : 'Commentaire rendu visible.');
                        }}
                        className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors ${
                          comm.status === 'hidden'
                            ? 'bg-emerald-900/60 text-emerald-300 hover:bg-emerald-800/60'
                            : 'bg-amber-900/60 text-amber-300 hover:bg-amber-800/60'
                        }`}
                      >
                        {comm.status === 'hidden' ? 'Débloquer / Rendre visible' : 'Masquer'}
                      </button>

                      <button
                        onClick={() => {
                          if (confirm('Supprimer définitivement ce commentaire ?')) {
                            deleteComment(comm.id);
                            showToast('Commentaire supprimé.');
                          }
                        }}
                        className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-slate-800 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: MEMBERS MANAGEMENT */}
        {activeTab === 'members' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Gestion des Membres & Inscriptions
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Validez les profils d’étudiants et docteurs, modifiez leurs informations ou ajoutez manuellement des adhérents.
                </p>
              </div>

              <button
                onClick={handleOpenNewMember}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-sm transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Ajouter un membre</span>
              </button>
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={memberSearch}
                  onChange={(e) => setMemberSearch(e.target.value)}
                  placeholder="Rechercher par nom, matricule ou email..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="flex items-center gap-2 text-xs">
                {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setMemberFilterStatus(st)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                      memberFilterStatus === st
                        ? 'bg-slate-700 text-white border border-slate-600'
                        : 'bg-slate-800/60 text-slate-400 hover:text-white'
                    }`}
                  >
                    {st === 'all' ? 'Tous' : st === 'pending' ? 'En attente' : st === 'approved' ? 'Vérifiés' : 'Refusés'}
                  </button>
                ))}
              </div>
            </div>

            {/* Members Table */}
            <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Nom & Rôle</th>
                      <th className="p-4">Matricule & Année</th>
                      <th className="p-4">Contacts</th>
                      <th className="p-4">Statut</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredMembers.map((member) => (
                      <tr key={member.id} className="hover:bg-slate-900/50 transition-colors">
                        <td className="p-4">
                          <p className="font-bold text-white text-sm">{member.name}</p>
                          <span className="text-[10px] uppercase font-bold text-emerald-400">
                            {member.role === 'student' ? 'Étudiant FSS' : member.role === 'doctor' ? 'Docteur Pharmacie' : member.role}
                          </span>
                        </td>
                        <td className="p-4 text-slate-300">
                          <p className="font-medium">{member.facultyId || 'N/A'}</p>
                          <p className="text-[11px] text-slate-500">{member.academicYear || '-'}</p>
                        </td>
                        <td className="p-4 text-slate-400">
                          <p>{member.email}</p>
                          <p className="text-[11px] text-slate-500">{member.phone || '-'}</p>
                        </td>
                        <td className="p-4">
                          {member.status === 'approved' ? (
                            <span className="inline-flex items-center gap-1 text-emerald-400 font-bold text-[11px]">
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>Certifié</span>
                            </span>
                          ) : member.status === 'pending' ? (
                            <span className="inline-flex items-center gap-1 text-amber-400 font-bold text-[11px]">
                              <Clock className="w-3.5 h-3.5" />
                              <span>En attente</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-rose-400 font-bold text-[11px]">
                              <X className="w-3.5 h-3.5" />
                              <span>Refusé</span>
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {member.status !== 'approved' && (
                              <button
                                onClick={() => {
                                  approveMember(member.id);
                                  showToast(`${member.name} certifié avec succès !`);
                                }}
                                className="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors"
                              >
                                Valider
                              </button>
                            )}

                            {member.status === 'pending' && (
                              <button
                                onClick={() => {
                                  rejectMember(member.id);
                                  showToast(`${member.name} refusé.`);
                                }}
                                className="px-2 py-1 text-[11px] font-bold bg-rose-900/60 hover:bg-rose-800/60 text-rose-300 rounded-lg transition-colors"
                              >
                                Refuser
                              </button>
                            )}

                            <button
                              onClick={() => handleEditMember(member)}
                              className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                              title="Modifier"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                if (confirm(`Supprimer le membre ${member.name} ?`)) {
                                  deleteMember(member.id);
                                  showToast('Membre supprimé.');
                                }
                              }}
                              className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                              title="Supprimer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: HEALTH & WHO/VIDAL HOURLY SYNC */}
        {activeTab === 'health' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white font-heading">
                  Veille Sanitaire • Synchronisation VIDAL & OMS
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Les brèves de santé s’actualisent chaque heure depuis l’OMS et le VIDAL. Vous pouvez déclencher une synchronisation ou importer manuellement un article.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() => syncHealthWithOmsAndVidal()}
                  disabled={isSyncingHealth}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold text-xs rounded-xl border border-teal-500/30 transition-colors"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isSyncingHealth ? 'animate-spin' : ''}`} />
                  <span>{isSyncingHealth ? 'Synchronisation...' : 'Actualiser OMS & Vidal'}</span>
                </button>

                <button
                  onClick={() => setIsHealthModalOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.admin.btnNewHealth}</span>
                </button>
              </div>
            </div>

            {/* Sync status card */}
            <div className="p-4 rounded-2xl bg-teal-950/40 border border-teal-800/60 flex items-center justify-between text-xs text-teal-200">
              <div className="flex items-center gap-3">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span>{lastHealthSyncTime}</span>
              </div>
              <span className="text-[11px] text-teal-400">Vérification automatique active</span>
            </div>

            {/* Health articles list */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {healthArticles.map((art) => (
                <div
                  key={art.id}
                  className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        art.sourceType === 'VIDAL' 
                          ? 'bg-amber-950 text-amber-400 border border-amber-800' 
                          : 'bg-blue-950 text-blue-400 border border-blue-800'
                      }`}>
                        Source : {art.sourceType}
                      </span>
                      <span className="text-xs text-slate-500">{art.publishDate}</span>
                    </div>

                    <h4 className="font-bold text-white text-base mt-1">{art.title.fr}</h4>
                    <p className="text-xs text-slate-300 mt-2 leading-relaxed line-clamp-3">{art.summary.fr}</p>

                    <div className="mt-3 text-[11px] text-slate-400">
                      <span>Organisme : <strong className="text-white">{art.source}</strong></span>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                    <a
                      href={art.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-teal-400 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Document d'origine</span>
                    </a>

                    <button
                      onClick={() => {
                        if (confirm('Supprimer cette brève santé ?')) {
                          deleteHealthArticle(art.id);
                          showToast('Article supprimé.');
                        }
                      }}
                      className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-slate-800 transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>

      {/* --- MODAL 1: POST CREATE / EDIT --- */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white font-heading">
                {editingPostId ? 'Modifier la Publication' : 'Nouvelle Publication AEPHAT'}
              </h3>
              <button onClick={() => setIsPostModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Titre (Français) *</label>
                <input
                  type="text"
                  required
                  value={postForm.titleFr}
                  onChange={(e) => setPostForm({ ...postForm, titleFr: e.target.value })}
                  placeholder="Titre en français..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Titre (Anglais - facultatif)</label>
                <input
                  type="text"
                  value={postForm.titleEn}
                  onChange={(e) => setPostForm({ ...postForm, titleEn: e.target.value })}
                  placeholder="English title..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Catégorie</label>
                  <select
                    value={postForm.category}
                    onChange={(e) => setPostForm({ ...postForm, category: e.target.value as PostCategory })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                  >
                    <option value="evenement">Événement Associatif</option>
                    <option value="academique">Académique & Pédagogique</option>
                    <option value="humanitaire">Humanitaire & Santé</option>
                    <option value="vie_etudiante">Vie Étudiante & Campus</option>
                  </select>
                </div>

                {/* Status: Published, Scheduled, Draft */}
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Diffusion & Programmation</label>
                  <select
                    value={postForm.status}
                    onChange={(e) => setPostForm({ ...postForm, status: e.target.value as PostStatus })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none font-bold text-amber-400"
                  >
                    <option value="published">Publier immédiatement</option>
                    <option value="scheduled">Programmer la publication</option>
                    <option value="draft">Enregistrer comme brouillon</option>
                  </select>
                </div>
              </div>

              {/* Scheduled date/time picker if scheduled */}
              {postForm.status === 'scheduled' && (
                <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl">
                  <label className="block text-amber-300 font-bold mb-1">Date et heure de publication programmée *</label>
                  <input
                    type="datetime-local"
                    required
                    value={postForm.scheduledDate}
                    onChange={(e) => setPostForm({ ...postForm, scheduledDate: e.target.value })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-bold mb-1">Résumé / Accroche (Français) *</label>
                <textarea
                  rows={2}
                  required
                  value={postForm.excerptFr}
                  onChange={(e) => setPostForm({ ...postForm, excerptFr: e.target.value })}
                  placeholder="Bref résumé affiché sur la carte..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Texte intégral (Français) *</label>
                <textarea
                  rows={4}
                  required
                  value={postForm.contentFr}
                  onChange={(e) => setPostForm({ ...postForm, contentFr: e.target.value })}
                  placeholder="Contenu complet de l'article..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Auteur</label>
                  <input
                    type="text"
                    value={postForm.author}
                    onChange={(e) => setPostForm({ ...postForm, author: e.target.value })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">URL Image de couverture</label>
                  <input
                    type="url"
                    value={postForm.imageUrl}
                    onChange={(e) => setPostForm({ ...postForm, imageUrl: e.target.value })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="isTestPost"
                  checked={postForm.isTestPost}
                  onChange={(e) => setPostForm({ ...postForm, isTestPost: e.target.checked })}
                  className="rounded bg-slate-950 border-slate-700 text-amber-500 focus:ring-0"
                />
                <label htmlFor="isTestPost" className="text-slate-300">Marquer comme article de test (facilement identifiable)</label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsPostModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl"
                >
                  {editingPostId ? 'Mettre à jour la publication' : 'Enregistrer et publier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 2: BOARD MEMBER CREATE / EDIT --- */}
      {isBoardModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white font-heading">
                {editingBoardId ? 'Modifier le membre du bureau' : 'Ajouter un poste / membre au bureau'}
              </h3>
              <button onClick={() => setIsBoardModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBoard} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Nom et Prénoms du responsable *</label>
                <input
                  type="text"
                  required
                  value={boardForm.name}
                  onChange={(e) => setBoardForm({ ...boardForm, name: e.target.value })}
                  placeholder="Ex: Kofi Mawuli Mensah"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Poste / Rôle (Français) *</label>
                  <input
                    type="text"
                    required
                    value={boardForm.roleFr}
                    onChange={(e) => setBoardForm({ ...boardForm, roleFr: e.target.value })}
                    placeholder="Ex: Président, Trésorier..."
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Niveau / Promotion</label>
                  <input
                    type="text"
                    value={boardForm.level}
                    onChange={(e) => setBoardForm({ ...boardForm, level: e.target.value })}
                    placeholder="Ex: 5ème Année Pharmacie"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Téléphone</label>
                  <input
                    type="tel"
                    value={boardForm.phone}
                    onChange={(e) => setBoardForm({ ...boardForm, phone: e.target.value })}
                    placeholder="+228 90 00 00 00"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Numéro WhatsApp</label>
                  <input
                    type="text"
                    value={boardForm.whatsapp}
                    onChange={(e) => setBoardForm({ ...boardForm, whatsapp: e.target.value })}
                    placeholder="22890000000"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Adresse Email</label>
                  <input
                    type="email"
                    value={boardForm.email}
                    onChange={(e) => setBoardForm({ ...boardForm, email: e.target.value })}
                    placeholder="contact@aephat.tg"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">URL de la photo / avatar</label>
                <input
                  type="url"
                  value={boardForm.photoUrl}
                  onChange={(e) => setBoardForm({ ...boardForm, photoUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Biographie / Attributions (Français)</label>
                <textarea
                  rows={3}
                  value={boardForm.bioFr}
                  onChange={(e) => setBoardForm({ ...boardForm, bioFr: e.target.value })}
                  placeholder="Missions du poste, coordination des projets..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsBoardModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 3: SURVEY CREATE / EDIT --- */}
      {isSurveyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white font-heading">
                Nouveau Sondage d'Opinion
              </h3>
              <button onClick={() => setIsSurveyModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSurvey} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Titre du sondage *</label>
                <input
                  type="text"
                  required
                  value={surveyForm.titleFr}
                  onChange={(e) => setSurveyForm({ ...surveyForm, titleFr: e.target.value })}
                  placeholder="Ex: Consultation sur le nouveau calendrier des examens..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Description *</label>
                <textarea
                  rows={3}
                  required
                  value={surveyForm.descriptionFr}
                  onChange={(e) => setSurveyForm({ ...surveyForm, descriptionFr: e.target.value })}
                  placeholder="Objectif de l'enquête, public ciblé..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">URL Google Forms</label>
                  <input
                    type="url"
                    value={surveyForm.googleFormUrl}
                    onChange={(e) => setSurveyForm({ ...surveyForm, googleFormUrl: e.target.value })}
                    placeholder="https://docs.google.com/forms/..."
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>

                {/* Associated Email for Google Forms results access */}
                <div>
                  <label className="block text-amber-300 font-bold mb-1">
                    Email associé aux résultats Google Forms *
                  </label>
                  <input
                    type="email"
                    required
                    value={surveyForm.resultsAccessEmail}
                    onChange={(e) => setSurveyForm({ ...surveyForm, resultsAccessEmail: e.target.value })}
                    placeholder="ex: commission.elections@aephat.tg"
                    className="w-full p-2.5 bg-slate-950 border border-amber-600/60 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Date d'échéance</label>
                  <input
                    type="text"
                    value={surveyForm.deadline}
                    onChange={(e) => setSurveyForm({ ...surveyForm, deadline: e.target.value })}
                    placeholder="Ex: 30 Avril 2026"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Restriction d'accès</label>
                  <select
                    value={surveyForm.restriction}
                    onChange={(e) => setSurveyForm({ ...surveyForm, restriction: e.target.value as any })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  >
                    <option value="all_with_email">Ouvert à tous avec email</option>
                    <option value="verified_only">Membres vérifiés uniquement (Étudiants / Docteurs)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSurveyModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl"
                >
                  Créer le sondage
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 4: HEALTH ARTICLE IMPORT (MANUAL OR 1-CLICK PRESETS) --- */}
      {isHealthModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white font-heading">
                Importer une Brève de Santé Officielle
              </h3>
              <button onClick={() => setIsHealthModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick 1-Click Import Presets */}
            <div className="mb-4 p-3 bg-slate-950 rounded-xl border border-slate-800">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                Pré-remplir depuis les flux officiels en 1 clic :
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleImportPreset('vidal_alert')}
                  className="p-2.5 rounded-lg bg-amber-950/40 hover:bg-amber-900/40 border border-amber-800/60 text-amber-300 text-left text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Alerte VIDAL France 2026</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleImportPreset('who_bulletin')}
                  className="p-2.5 rounded-lg bg-blue-950/40 hover:bg-blue-900/40 border border-blue-800/60 text-blue-300 text-left text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Globe2 className="w-3.5 h-3.5" />
                  <span>Bulletin OMS Afrique 2026</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveHealthArticle} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Titre de l'article *</label>
                <input
                  type="text"
                  required
                  value={healthForm.titleFr}
                  onChange={(e) => setHealthForm({ ...healthForm, titleFr: e.target.value })}
                  placeholder="Titre officiel..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Organisme source</label>
                  <select
                    value={healthForm.sourceType}
                    onChange={(e) => setHealthForm({ ...healthForm, sourceType: e.target.value as HealthSource })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  >
                    <option value="VIDAL">Base de données VIDAL France</option>
                    <option value="OMS">Organisation Mondiale de la Santé (OMS)</option>
                    <option value="MINISTERE_TOGO">Ministère de la Santé du Togo</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Thématique</label>
                  <select
                    value={healthForm.category}
                    onChange={(e) => setHealthForm({ ...healthForm, category: e.target.value as HealthCategory })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  >
                    <option value="pharmacovigilance">Pharmacovigilance & Sécurité</option>
                    <option value="alerte">Alerte Sanitaire</option>
                    <option value="prevention">Prévention & Bon usage</option>
                    <option value="recherche">Recherche & Médicament</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Résumé concis *</label>
                <textarea
                  rows={2}
                  required
                  value={healthForm.summaryFr}
                  onChange={(e) => setHealthForm({ ...healthForm, summaryFr: e.target.value })}
                  placeholder="Points clés pour les pharmaciens..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Corps de texte détaillé *</label>
                <textarea
                  rows={4}
                  required
                  value={healthForm.contentFr}
                  onChange={(e) => setHealthForm({ ...healthForm, contentFr: e.target.value })}
                  placeholder="Détails cliniques, posologies, précautions..."
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Nom complet source</label>
                  <input
                    type="text"
                    value={healthForm.source}
                    onChange={(e) => setHealthForm({ ...healthForm, source: e.target.value })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Lien URL source</label>
                  <input
                    type="url"
                    value={healthForm.sourceUrl}
                    onChange={(e) => setHealthForm({ ...healthForm, sourceUrl: e.target.value })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsHealthModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl"
                >
                  Importer et publier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 5: MEMBER CREATE / EDIT --- */}
      {isMemberModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white font-heading">
                {editingMemberId ? 'Modifier le Membre' : 'Ajouter un Nouveau Membre'}
              </h3>
              <button onClick={() => setIsMemberModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMember} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Nom et Prénoms *</label>
                <input
                  type="text"
                  required
                  value={memberForm.name}
                  onChange={(e) => setMemberForm({ ...memberForm, name: e.target.value })}
                  placeholder="Ex: Kodjo Mensah"
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={memberForm.email}
                    onChange={(e) => setMemberForm({ ...memberForm, email: e.target.value })}
                    placeholder="etudiant@univ-lome.tg"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Téléphone</label>
                  <input
                    type="tel"
                    value={memberForm.phone}
                    onChange={(e) => setMemberForm({ ...memberForm, phone: e.target.value })}
                    placeholder="+228 90 00 00 00"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Rôle</label>
                  <select
                    value={memberForm.role}
                    onChange={(e) => setMemberForm({ ...memberForm, role: e.target.value as UserRole })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  >
                    <option value="student">Étudiant en Pharmacie (FSS)</option>
                    <option value="doctor">Docteur en Pharmacie (Alumni/ONPT)</option>
                    <option value="healthcare_pro">Professionnel de santé</option>
                    <option value="citizen">Citoyen / Usager</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Statut d'adhésion</label>
                  <select
                    value={memberForm.status}
                    onChange={(e) => setMemberForm({ ...memberForm, status: e.target.value as User['status'] })}
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold"
                  >
                    <option value="approved">Validé / Certifié (Accès complet)</option>
                    <option value="pending">En attente de revue</option>
                    <option value="rejected">Refusé</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Matricule / Identifiant</label>
                  <input
                    type="text"
                    value={memberForm.facultyId}
                    onChange={(e) => setMemberForm({ ...memberForm, facultyId: e.target.value })}
                    placeholder="Ex: FSS-PHARM-2023-019"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Année académique</label>
                  <input
                    type="text"
                    value={memberForm.academicYear}
                    onChange={(e) => setMemberForm({ ...memberForm, academicYear: e.target.value })}
                    placeholder="Ex: 4ème Année Pharmacie"
                    className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsMemberModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
