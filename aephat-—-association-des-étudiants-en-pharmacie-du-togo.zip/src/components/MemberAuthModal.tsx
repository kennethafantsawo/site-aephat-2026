import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { 
  X, 
  UserCheck, 
  ShieldCheck, 
  GraduationCap, 
  Stethoscope, 
  Users, 
  Sparkles,
  CheckCircle2, 
  AlertCircle,
  LogIn,
  UserPlus,
  KeyRound,
  Phone
} from 'lucide-react';

export const MemberAuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    setIsAuthModalOpen, 
    authModalTab,
    setAuthModalTab,
    registerMember, 
    login,
    loginAsDemoUser, 
    language, 
    t 
  } = useApp();

  // Registration state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [facultyId, setFacultyId] = useState('');
  const [academicYear, setAcademicYear] = useState('4ème Année Pharmacie');

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    registerMember({
      name,
      email,
      phone,
      role,
      facultyId: role === 'student' || role === 'doctor' ? facultyId : undefined,
      academicYear: role === 'student' ? academicYear : undefined,
    });

    setSubmittedMessage(
      role === 'student' || role === 'doctor'
        ? (language === 'fr' 
            ? 'Demande enregistrée ! Votre profil étudiant/docteur a été transmis pour vérification par le bureau AEPHAT.' 
            : 'Request registered! Your student/doctor profile is pending verification by the AEPHAT board.')
        : (language === 'fr' 
            ? 'Compte citoyen créé avec succès ! Bienvenue au sein de l’AEPHAT.' 
            : 'Account successfully created! Welcome to AEPHAT.')
    );

    setTimeout(() => {
      setSubmittedMessage(null);
      setIsAuthModalOpen(false);
    }, 2000);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) return;

    login(loginEmail, loginPassword);
    setSubmittedMessage(
      language === 'fr' 
        ? `Ravi de vous revoir ! Connexion réussie.` 
        : `Welcome back! Signed in successfully.`
    );

    setTimeout(() => {
      setSubmittedMessage(null);
      setIsAuthModalOpen(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[92vh] overflow-y-auto animate-fade-in">
        
        {/* Close button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
            <UserCheck className="w-3.5 h-3.5" />
            <span>{t.memberModal.title}</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-2 font-heading">
            {authModalTab === 'login' ? t.memberModal.tabLogin : t.memberModal.tabRegister}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {t.memberModal.subtitle}
          </p>
        </div>

        {/* Success Alert */}
        {submittedMessage && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-2.5 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
            <span>{submittedMessage}</span>
          </div>
        )}

        {/* Tab Toggle: Se connecter vs Créer un compte */}
        <div className="flex border-b border-slate-200 mb-6">
          <button
            type="button"
            onClick={() => setAuthModalTab('login')}
            className={`flex-1 pb-3 text-xs font-bold transition-colors border-b-2 flex items-center justify-center gap-1.5 ${
              authModalTab === 'login'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>{t.memberModal.tabLogin}</span>
          </button>
          <button
            type="button"
            onClick={() => setAuthModalTab('register')}
            className={`flex-1 pb-3 text-xs font-bold transition-colors border-b-2 flex items-center justify-center gap-1.5 ${
              authModalTab === 'register'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>{t.memberModal.tabRegister}</span>
          </button>
        </div>

        {authModalTab === 'login' ? (
          <div className="space-y-6">
            {/* Direct Login Form */}
            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.memberModal.email} *
                </label>
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="Ex: kofi.mensah@fss.univ-lome.tg"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.memberModal.password}
                </label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="•••••••• (Facultatif en mode test)"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
              >
                <LogIn className="w-4 h-4" />
                <span>{t.memberModal.submitLogin}</span>
              </button>
            </form>

            {/* Quick 1-click demo logins */}
            <div className="pt-4 border-t border-slate-100">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-3">
                {t.memberModal.loginAsTestUser}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={() => loginAsDemoUser('student')}
                  className="p-3 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-emerald-700 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Kofi Mensah</p>
                      <p className="text-[10px] text-emerald-800">Étudiant 5e Année</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700">→</span>
                </button>

                <button
                  onClick={() => loginAsDemoUser('doctor')}
                  className="p-3 rounded-xl border border-blue-300 bg-blue-50 hover:bg-blue-100 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Dr. Ayélé Lawson</p>
                      <p className="text-[10px] text-blue-800">Docteur Pharmacie</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-blue-700">→</span>
                </button>

                <button
                  onClick={() => loginAsDemoUser('citizen')}
                  className="p-3 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-slate-700 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Ablam Doe</p>
                      <p className="text-[10px] text-slate-600">Citoyen / Usager</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-slate-700">→</span>
                </button>

                <button
                  onClick={() => loginAsDemoUser('admin')}
                  className="p-3 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-amber-700 shrink-0" />
                    <div>
                      <p className="text-xs font-bold text-slate-900">Bureau AEPHAT</p>
                      <p className="text-[10px] text-amber-800">Admin Privilégié</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-amber-700">→</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.memberModal.fullName} *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Kodjo Afantsawo"
                className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.memberModal.email} *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Ex: etudiant@univ-lome.tg"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.memberModal.phone}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+228 90 00 00 00"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.memberModal.roleLabel}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRole('student')}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 ${
                    role === 'student' 
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold' 
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <GraduationCap className="w-4 h-4 text-emerald-600" />
                  <span>{t.memberModal.roleStudent}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('doctor')}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 ${
                    role === 'doctor' 
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold' 
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{t.memberModal.roleDoctor}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('healthcare_pro')}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 ${
                    role === 'healthcare_pro' 
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold' 
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Stethoscope className="w-4 h-4 text-emerald-600" />
                  <span>{t.memberModal.roleHealthcarePro}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('citizen')}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 ${
                    role === 'citizen' 
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold' 
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>{t.memberModal.roleCitizen}</span>
                </button>
              </div>
            </div>

            {/* Extra fields for students & doctors */}
            {(role === 'student' || role === 'doctor') && (
              <div className="space-y-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t.memberModal.facultyIdLabel}
                  </label>
                  <input
                    type="text"
                    value={facultyId}
                    onChange={(e) => setFacultyId(e.target.value)}
                    placeholder="Ex: FSS-2023-0192"
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-200 bg-white"
                  />
                </div>

                {role === 'student' && (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {t.memberModal.yearLabel}
                    </label>
                    <select
                      value={academicYear}
                      onChange={(e) => setAcademicYear(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-200 bg-white"
                    >
                      <option value="2ème Année Pharmacie">2ème Année Pharmacie</option>
                      <option value="3ème Année Pharmacie">3ème Année Pharmacie</option>
                      <option value="4ème Année Pharmacie">4ème Année Pharmacie</option>
                      <option value="5ème Année (Internat)">5ème Année (Internat Hospitalier)</option>
                      <option value="Thèse de Doctorat">Préparation Thèse de Doctorat</option>
                    </select>
                  </div>
                )}

                <div className="flex items-start gap-1.5 text-[10px] text-slate-500">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-500 mt-0.5 shrink-0" />
                  <span>{t.memberModal.pendingNotice}</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors"
            >
              {t.memberModal.submitRegister}
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
