export type Language = 'fr' | 'en';

export type UserRole = 'visitor' | 'student' | 'doctor' | 'healthcare_pro' | 'citizen' | 'admin';

export type AdminRole = 'president' | 'vice_president' | 'comms_director';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  facultyId?: string;
  academicYear?: string;
  isVerified: boolean;
  status: 'pending' | 'approved' | 'rejected';
  avatar?: string;
  joinedAt: string;
  phone?: string;
}

export type PostCategory = 'evenement' | 'academique' | 'humanitaire' | 'vie_etudiante';
export type PostStatus = 'published' | 'scheduled' | 'draft';

export interface Post {
  id: string;
  title: {
    fr: string;
    en: string;
  };
  excerpt: {
    fr: string;
    en: string;
  };
  content: {
    fr: string;
    en: string;
  };
  category: PostCategory;
  author: string;
  authorRole: string;
  date: string;
  imageUrl?: string;
  likes: number;
  isTestPost?: boolean;
  allowComments: boolean;
  tags: string[];
  status: PostStatus;
  scheduledDate?: string;
}

export type HealthCategory = 'alerte' | 'prevention' | 'recherche' | 'pharmacovigilance';
export type HealthSource = 'OMS' | 'VIDAL' | 'MINISTERE_TOGO' | 'AFRICA_CDC';

export interface HealthArticle {
  id: string;
  title: {
    fr: string;
    en: string;
  };
  summary: {
    fr: string;
    en: string;
  };
  content: {
    fr: string;
    en: string;
  };
  source: string;
  sourceType: HealthSource;
  sourceUrl: string;
  verifiedBy: string;
  publishDate: string;
  category: HealthCategory;
  readTimeMinutes: number;
  importedAt?: string;
}

export interface SurveyOption {
  id: string;
  label: {
    fr: string;
    en: string;
  };
  votesCount: number;
  percent: number;
}

export interface Survey {
  id: string;
  title: {
    fr: string;
    en: string;
  };
  description: {
    fr: string;
    en: string;
  };
  googleFormUrl: string;
  googleFormEmbedUrl?: string;
  googleSpreadsheetStatsUrl?: string;
  resultsAccessEmail: string; // Associated email to access Google Form results
  restriction: 'all_with_email' | 'verified_only';
  deadline: string;
  responsesCount: number;
  isActive: boolean;
  resultsSummary: {
    total: number;
    options: SurveyOption[];
  };
}

export interface CommentItem {
  id: string;
  targetType: 'post' | 'survey' | 'suggestion';
  targetId: string;
  targetTitle: string;
  authorName: string;
  authorEmail: string;
  authorRole: UserRole;
  isVerifiedUser: boolean;
  content: string;
  createdAt: string;
  visibility: 'public' | 'private';
  status: 'published' | 'hidden' | 'unread' | 'reviewed';
  adminReply?: string;
}

export interface BoardMember {
  id: string;
  name: string;
  role: {
    fr: string;
    en: string;
  };
  category: 'executif' | 'scientifique' | 'communication' | 'pedagogique' | 'general';
  level: string;
  email: string;
  phone: string;
  whatsapp: string;
  photoUrl: string;
  bio: {
    fr: string;
    en: string;
  };
  order: number;
}
